<?php

use CodeIgniter\Commands\Utilities\Routes;
use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Login::index');
$routes->post('login', 'Login::login_action');
$routes->get('logout', 'Login::logout');


$routes->get('admin/home', 'Admin\Home::index', ['filter' => 'adminFilter']);
$routes->get('admin/jabatan', 'Admin\jabatan::index', ['filter' => 'adminFilter']);
$routes->get('admin/jabatan/create', 'Admin\jabatan::create', ['filter' => 'adminFilter']);
$routes->post('admin/jabatan/store', 'Admin\jabatan::store', ['filter' => 'adminFilter']);
$routes->get('admin/jabatan/edit/(:segment)', 'Admin\jabatan::edit/$1', ['filter' => 'adminFilter']);
$routes->post('admin/jabatan/update/(:segment)', 'Admin\jabatan::update/$1', ['filter' => 'adminFilter']);
$routes->get('admin/jabatan/delete/(:segment)', 'Admin\jabatan::delete/$1', ['filter' => 'adminFilter']);





$routes->get('admin/jabatan', 'Admin\jabatan::index', ['filter' => 'adminFilter']);
$routes->get('admin/jabatan/create', 'Admin\jabatan::create', ['filter' => 'adminFilter']);
$routes->post('admin/jabatan/store', 'Admin\jabatan::store', ['filter' => 'adminFilter']);
$routes->get('admin/jabatan/edit/(:segment)', 'Admin\jabatan::edit/$1', ['filter' => 'adminFilter']);
$routes->post('admin/jabatan/update/(:segment)', 'Admin\jabatan::update/$1', ['filter' => 'adminFilter']);
$routes->get('admin/jabatan/delete/(:segment)', 'Admin\jabatan::delete/$1', ['filter' => 'adminFilter']);





$routes->get('admin/lokasi_presensi', 'Admin\LokasiPresensi::index', ['filter' => 'adminFilter']);
$routes->get('admin/lokasi_presensi/create', 'Admin\LokasiPresensi::create', ['filter' => 'adminFilter']);
$routes->post('admin/lokasi_presensi/store', 'Admin\LokasiPresensi::store', ['filter' => 'adminFilter']);
$routes->get('admin/lokasi_presensi/edit/(:segment)', 'Admin\LokasiPresensi::edit/$1', ['filter' => 'adminFilter']);
$routes->post('admin/lokasi_presensi/update/(:segment)', 'Admin\LokasiPresensi::update/$1', ['filter' => 'adminFilter']);
$routes->get('admin/lokasi_presensi/delete/(:segment)', 'Admin\LokasiPresensi::delete/$1', ['filter' => 'adminFilter']);
$routes->get('admin/lokasi_presensi/detail/(:segment)', 'Admin\LokasiPresensi::detail/$1', ['filter' => 'adminFilter']);




$routes->get('admin/data_siswa', 'Admin\Datasiswa::index/$1', ['filter' => 'adminFilter']);
$routes->get('admin/data_siswa/create', 'Admin\Datasiswa::create', ['filter' => 'adminFilter']);
$routes->post('admin/data_siswa/store', 'Admin\Datasiswa::store', ['filter' => 'adminFilter']);
$routes->get('admin/data_siswa/edit/(:segment)', 'Admin\Datasiswa::edit/$1', ['filter' => 'adminFilter']);
$routes->post('admin/data_siswa/update/(:segment)', 'Admin\Datasiswa::update/$1', ['filter' => 'adminFilter']);
$routes->get('admin/data_siswa/delete/(:segment)', 'Admin\Datasiswa::delete/$1', ['filter' => 'adminFilter']);
$routes->get('admin/data_siswa/detail/(:segment)', 'Admin\Datasiswa::detail/$1', ['filter' => 'adminFilter']);




$routes->get('admin/rekap_harian', 'Admin\RekapPresensi::rekap_harian/', ['filter' => 'adminFilter']);
$routes->get('admin/detail_presensi/detail_harian/(:segment)', 'Admin\RekapPresensi::detail_harian/$1', ['filter' => 'adminFilter']);
$routes->get('admin/detail_presensi/detail_bulanan/(:segment)', 'Admin\RekapPresensi::detail_bulanan/$1', ['filter' => 'adminFilter']);
$routes->get('admin/rekap_bulanan', 'Admin\RekapPresensi::rekap_bulanan', ['filter' => 'adminFilter']);

$routes->get('admin/ketidakhadiran', 'Admin\Ketidakhadiran::index', ['filter' => 'adminFilter']);
$routes->get('admin/approved_ketidakhadiran/(:segment)', 'Admin\Ketidakhadiran::approved/$1', ['filter' => 'adminFilter']);
$routes->get('admin/ketidakhadiran/delete/(:segment)', 'Admin\Ketidakhadiran::delete/$1', ['filter' => 'adminFilter']);
// $routes->get('admin/paraf_absensi/(:segment)', 'Admin\RekapPresensi::paraf/$1',['filter' => 'adminFilter']);
// $routes->get('admin/paraf_absensi/harian/', 'Admin\RekapPresensi::parafharian/$1');
// $routes->get('admin/paraf_absensi/bulan/(:segment)', 'Admin\RekapPresensi::parafbulan/$1');
$routes->get('admin/paraf_absensi/harian/(:segment)', 'Admin\RekapPresensi::parafharian/$1', ['filter' => 'adminFilter']);
$routes->get('admin/paraf_absensi/bulanan/(:segment)', 'Admin\RekapPresensi::parafbulan/$1', ['filter' => 'adminFilter']);



$routes->get('siswa/home', 'Siswa\Home::index', ['filter' => 'pegawaiFilter']);
$routes->post('siswa/presensi_masuk', 'Siswa\Home::presensi_masuk', ['filter' => 'pegawaiFilter']);
$routes->post('siswa/presensi_masuk_aksi', 'Siswa\Home::presensi_masuk_aksi', ['filter' => 'pegawaiFilter']);
$routes->get('siswa/faq', 'Siswa\Home::faq', ['filter' => 'pegawaiFilter']);

// $routes->post('siswa/kegiatan', 'Siswa\Home::kegiatan');

// $routes->post('siswa/kegiatan/(:segment)', 'Siswa\Home::kegiatan/$1',['filter' => 'pegawaiFilter']); 
$routes->post('siswa/presensi_keluar/(:segment)', 'Siswa\Home::presensi_keluar/$1', ['filter' => 'pegawaiFilter']);
$routes->post('siswa/presensi_keluar_aksi/(:segment)', 'Siswa\Home::presensi_keluar_aksi/$1', ['filter' => 'pegawaiFilter']);

$routes->get('siswa/rekap_presensi/', 'Siswa\RekapPresensi::index/', ['filter' => 'pegawaiFilter']);
$routes->get('siswa/detail_presensi/(:segment)', 'Siswa\RekapPresensi::detail_presensi/$1', ['filter' => 'pegawaiFilter']);


$routes->get('siswa/ketidakhadiran', 'Siswa\Ketidakhadiran::index', ['filter' => 'pegawaiFilter']);
$routes->get('siswa/ketidakhadiran/create', 'Siswa\ketidakhadiran::create', ['filter' => 'pegawaiFilter']);
$routes->post('siswa/ketidakhadiran/store', 'Siswa\ketidakhadiran::store', ['filter' => 'pegawaiFilter']);
$routes->get('siswa/ketidakhadiran/edit/(:segment)', 'Siswa\Ketidakhadiran::edit/$1', ['filter' => 'pegawaiFilter']);
$routes->post('siswa/ketidakhadiran/update/(:segment)', 'Siswa\Ketidakhadiran::update/$1', ['filter' => 'pegawaiFilter']);
$routes->get('siswa/ketidakhadiran/delete/(:segment)', 'Siswa\Ketidakhadiran::delete/$1', ['filter' => 'pegawaiFilter']);
$routes->get('siswa/ketidakhadiran/detail/(:segment)', 'Siswa\Ketidakhadiran::detail/$1', ['filter' => 'pegawaiFilter']);
