<?php

namespace App\Models;

use CodeIgniter\Model;

class KetidakhadiranModel extends Model
{
    protected $table            = 'ketidakhadiran';
    protected $primaryKey       = 'id';
    protected $allowedFields    = [
        'id_siswa',
        'keterangan',
        'tanggal',
        'deskripsi',
        'file',
        'status'
    ];


    public function ketidakhadiran()
    {
        $db      = \Config\Database::connect();
        $builder = $db->table('ketidakhadiran');

        // Join dengan tabel siswa berdasarkan id_siswa
        $builder->select('ketidakhadiran.*, siswa.nama as nama_siswa ,ketidakhadiran.status');
        $builder->join('siswa', 'siswa.id = ketidakhadiran.id_siswa');
        return $builder->get()->getResultArray();
    }


    public function checkAbsensiToday()
    {
        $id_siswa = session()->get('id_siswa');
        $db = \Config\Database::connect();
        $builder = $db->table('presensi');
        $builder->where('id_siswa', $id_siswa);
        $builder->where('DATE(tanggal_masuk)', date('Y-m-d')); // Tanggal hari ini
        $absensi = $builder->get()->getRowArray();

        return $absensi ? true : false; // Mengembalikan true jika ada absensi, false jika tidak
    }
}
