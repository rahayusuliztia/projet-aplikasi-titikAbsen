<?php

namespace App\Models;

use CodeIgniter\Model;

class PresensiModel extends Model
{
    protected $table            = 'presensi';
    protected $allowedFields    = [
        'id_siswa',
        'tanggal_masuk',
        'jam_masuk',
        'foto_masuk',
        'tanggal_keluar',
        'jam_keluar',
        'foto_keluar',
        'kegiatan',
        'paraf',
    ];


    public function rekap_harian()
    {
        $db     = \Config\Database::connect();
        $builder = $db->table('presensi');
        $builder->select('presensi.*, siswa.nama, presensi.paraf, presensi.kegiatan, lokasi_presensi.jam_masuk as jam_masuk_kantor');
        $builder->join('siswa', 'siswa.id = presensi.id_siswa');
        $builder->join('lokasi_presensi', 'lokasi_presensi.id = siswa.lokasi_presensi');
        $builder->where('tanggal_masuk', date('Y-m-d'));
        $builder->orderBy('tanggal_masuk', 'DESC')->orderBy('jam_masuk', 'DESC');
        return $builder->get()->getResultArray();
    }


    // fungsi detail
    public function rekap_harian_by_id($id)
    {
        $db     = \Config\Database::connect();
        $builder = $db->table('presensi');
        $builder->select('presensi.*, siswa.nama, presensi.paraf, presensi.kegiatan, lokasi_presensi.jam_masuk as jam_masuk_kantor, lokasi_presensi.jam_pulang as jam_pulang_kantor, presensi.jam_keluar');
        $builder->join('siswa', 'siswa.id = presensi.id_siswa');
        $builder->join('lokasi_presensi', 'lokasi_presensi.id = siswa.lokasi_presensi');
        $builder->where('presensi.id', $id); // Filter by siswa ID
        $builder->orderBy('tanggal_masuk', 'DESC')->orderBy('jam_masuk', 'DESC');
        $result = $builder->get()->getResultArray();
        return $result;
    }

    // fungsi detail
    public function rekap_harian_filter_id($filter_tanggal, $id)
    {
        $db     = \Config\Database::connect();
        $builder = $db->table('presensi');
        $builder->select('presensi.*, siswa.nama, presensi.paraf, presensi.kegiatan, lokasi_presensi.jam_masuk as jam_masuk_kantor ,lokasi_presensi.jam_pulang as jam_pulang_kantor ,presensi.jam_keluar');
        $builder->join('siswa', 'siswa.id = presensi.id_siswa');
        $builder->join('lokasi_presensi', 'lokasi_presensi.id = siswa.lokasi_presensi');
        $builder->where('DATE(tanggal_masuk)', $filter_tanggal);
        $builder->where('presensi.id', $id); // Filter by siswa ID
        $builder->orderBy('tanggal_masuk', 'DESC')->orderBy('jam_masuk', 'DESC');
        return $builder->get()->getResultArray();
    }

    public function rekap_harian_filter($filter_tanggal)
    {
        $db      = \Config\Database::connect();
        $builder = $db->table('presensi');
        $builder->select('presensi.*, siswa.nama, presensi.paraf, presensi.kegiatan, lokasi_presensi.jam_masuk as jam_masuk_kantor');
        $builder->join('siswa', 'siswa.id = presensi.id_siswa');
        $builder->join('lokasi_presensi', 'lokasi_presensi.id = siswa.lokasi_presensi');
        $builder->where('DATE(tanggal_masuk)', $filter_tanggal);
        $builder->orderBy('tanggal_masuk', 'DESC')->orderBy('jam_masuk', 'DESC');
        return $builder->get()->getResultArray();
    }

    public function rekap_bulanan_filter($filter_bulan, $filter_tahun,)
    {
        $db     = \Config\Database::connect();
        $builder = $db->table('presensi');
        $builder->select('presensi.*, siswa.nama, lokasi_presensi.jam_masuk as jam_masuk_kantor');
        $builder->join('siswa', 'siswa.id = presensi.id_siswa');
        $builder->join('lokasi_presensi', 'lokasi_presensi.id = siswa.lokasi_presensi');
        $builder->where('MONTH(tanggal_masuk)', $filter_bulan);
        $builder->where('YEAR(tanggal_masuk)', $filter_tahun);
        $builder->orderBy('tanggal_masuk', 'DESC')->orderBy('jam_masuk', 'DESC');
        return $builder->get()->getResultArray();
    }

    public function rekap_bulanan()
    {
        $db     = \Config\Database::connect();
        $builder = $db->table('presensi');
        $builder->select('presensi.*, siswa.nama, presensi.kegiatan, lokasi_presensi.jam_masuk as jam_masuk_kantor');
        $builder->join('siswa', 'siswa.id = presensi.id_siswa');
        $builder->join('lokasi_presensi', 'lokasi_presensi.id = siswa.lokasi_presensi');
        $builder->where('MONTH(tanggal_masuk)', date('m'));
        $builder->where('YEAR(tanggal_masuk)', date('Y'));
        $builder->orderBy('tanggal_masuk', 'DESC')->orderBy('jam_masuk', 'DESC');
        return $builder->get()->getResultArray();
    }


    // query detail bulanan
    public function rekap_bulanan_filter_id($filter_bulan, $filter_tahun, $id)
    {
        $db     = \Config\Database::connect();
        $builder = $db->table('presensi');
        $builder->select('presensi.*, siswa.nama, lokasi_presensi.jam_masuk as jam_masuk_kantor,lokasi_presensi.jam_pulang as jam_pulang_kantor ,presensi.jam_keluar');
        $builder->join('siswa', 'siswa.id = presensi.id_siswa');
        $builder->join('lokasi_presensi', 'lokasi_presensi.id = siswa.lokasi_presensi');
        $builder->where('MONTH(tanggal_masuk)', $filter_bulan);
        $builder->where('YEAR(tanggal_masuk)', $filter_tahun);
        $builder->where('presensi.id', $id); // Filter by siswa ID
        $builder->orderBy('tanggal_masuk', 'DESC')->orderBy('jam_masuk', 'DESC');
        return $builder->get()->getResultArray();
    }

    // query detail bulanan
    public function rekap_bulanan_by_id($id)
    {
        $db     = \Config\Database::connect();
        $builder = $db->table('presensi');
        $builder->select('presensi.*, siswa.nama, lokasi_presensi.jam_masuk as jam_masuk_kantor ,lokasi_presensi.jam_pulang as jam_pulang_kantor ,presensi.jam_keluar');
        $builder->join('siswa', 'siswa.id = presensi.id_siswa');
        $builder->join('lokasi_presensi', 'lokasi_presensi.id = siswa.lokasi_presensi');
        $builder->where('presensi.id', $id); // Filter by siswa ID
        $builder->orderBy('tanggal_masuk', 'DESC')->orderBy('jam_masuk', 'DESC');
        return $builder->get()->getResultArray();
    }

    public function rekap_presensi_siswa_today()
    {
        $id_siswa = session()->get('id_siswa');
        $db = \Config\Database::connect();
        $builder = $db->table('presensi');
        $builder->select('presensi.*, siswa.nama, lokasi_presensi.jam_masuk as jam_masuk_kantor');
        $builder->join('siswa', 'siswa.id = presensi.id_siswa');
        $builder->join('lokasi_presensi', 'lokasi_presensi.id = siswa.lokasi_presensi');
        $builder->where('id_siswa', $id_siswa);

        // Menggunakan raw SQL agar CURDATE() bekerja dengan baik
        $builder->where('DATE(presensi.tanggal_masuk) = CURDATE()', null, false);

        $result = $builder->get()->getResultArray();

        // dd($result); // Debug hasil query
        return $result;
    }





    public function rekap_presensi_siswa_filter($filter_tanggal)
    {
        $id_siswa = session()->get('id_siswa');
        $db     = \Config\Database::connect();
        $builder = $db->table('presensi');
        $builder->select('presensi.*, siswa.nama, lokasi_presensi.jam_masuk as jam_masuk_kantor');
        $builder->join('siswa', 'siswa.id = presensi.id_siswa');
        $builder->join('lokasi_presensi', 'lokasi_presensi.id = siswa.lokasi_presensi');
        $builder->where('id_siswa', $id_siswa);
        $builder->where('tanggal_masuk', $filter_tanggal);
        return $builder->get()->getResultArray();
    }
}
