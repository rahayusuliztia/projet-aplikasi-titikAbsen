<?php

namespace App\Models;

use CodeIgniter\Model;

class SiswaModel extends Model
{
    protected $table            = 'siswa';
    protected $allowedFields    = [
        'nisn',
        'nama',
        'jenis_kelamin',
        'alamat',
        'no_hanphone',
        'jabatan',
        'lokasi_presensi',
        'foto_siswa',
    ];

    public function detailSiswa($id)
    {
        $db      = \Config\Database::connect();
        $builder = $db->table('siswa');
        $builder->select('siswa.*, user.username, user.status, user.role');
        $builder->join('user', 'user.id_siswa = siswa.id');
        $builder->where('siswa.id', $id);
        return $builder->get()->getRowArray();
    }

    public function editSiswa($id)
    {
        $db      = \Config\Database::connect();
        $builder = $db->table('siswa');
        $builder->select('siswa.*, user.username, user.password, user.status, user.role');
        $builder->join('user', 'user.id_siswa = siswa.id');
        $builder->where('siswa.id', $id);
        return $builder->get()->getRowArray();
    }
}
