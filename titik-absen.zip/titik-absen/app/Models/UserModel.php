<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table            = 'user';
    protected $allowedFields    = [
        'id_siswa',
        'username',
        'password',
        'status',
        'role',
    ];

    
}
