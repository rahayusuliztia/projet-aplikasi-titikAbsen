<?php

namespace App\Controllers;

use App\Models\LoginModel;
use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use Predis\Command\Argument\Server\To;

class Login extends BaseController
{
    public function index()
    {
        $data = [
            'validation' => \Config\Services::validation()
        ];

        return view('login', $data);
    }


    public function login_action()
    {
        $rules = [
            'username' => 'required',
            'password' => 'required',
        ];

        if (!$this->validate($rules)) {
            $data['validation'] = $this->validator;
            return view('login', $data);
        } else {
            $session = session();
            $loginModel = new loginModel;

            $username = $this->request->getVar('username');
            $password = $this->request->getVar('password');
            $cekusername = $loginModel->where('username', $username)->first();
            
            if($cekusername) {
                $password_db = $cekusername['password'];
                $cek_password = password_verify($password, $password_db);

                if($cek_password) {

                    $session_data = [
                        'username' => $cekusername['username'],
                        'loged_in' =>  TRUE,
                        'role_id' => $cekusername['role'],
                        'id_siswa' => $cekusername['id'],
                    ];
                    
                    $session->set($session_data);

                    switch($cekusername['role']) {
                        case "admin":
                            return redirect()->to('admin/home');
                        case "siswa":
                            return redirect()->to('siswa/home');
                        default :
                        $session->setFlashdata('Pesan', 'Akun anda belum terdaftar ');
                        return redirect()->to('/');
                        }
                     }else {
                    $session->setFlashdata('Pesan', 'password salah, silahkan coba lagi');
                return redirect()->to('/');
                }
            } else {
                $session->setFlashdata('Pesan', 'Username salah, silahkan coba lagi');
                return redirect()->to('/');
            }
        } 

    }

    public function logout()
     {
        $session = session();
        $session->destroy();
        return redirect()->to('/');
    }
}
