<?php

namespace App\Controllers\Siswa;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\LokasiPresensiModel;
use App\Models\SiswaModel;
use App\Models\PresensiModel;
use App\Models\KetidakhadiranModel;


class Home extends BaseController
{
    protected $db;

    public function __construct()
    {
        helper(['url', 'form']);

        // Load database
        $this->db = \Config\Database::connect();
    }

    public function index()
    {
        $lokasi_presensi_model = new LokasiPresensiModel();
        $siswa_model = new SiswaModel();
        $presensi_model = new PresensiModel();

        // Ambil ID siswa dari session
        $id_siswa = session()->get('id_siswa');

        // Ambil data siswa berdasarkan ID
        $siswa = $siswa_model->where('id', $id_siswa)->first();

        // Pastikan data siswa tersedia
        if ($siswa) {
            // Tambahkan 'foto_siswa' ke session tanpa menimpa flashdata
            session()->set(['foto' => $siswa['foto_siswa']]);
        }

        // Ambil data lokasi_presensi
        $lokasi_presensi = $lokasi_presensi_model->where('id', $siswa['lokasi_presensi'])->first();

        // Atur zona waktu berdasarkan lokasi_presensi
        if ($lokasi_presensi['zona_waktu'] == 'WIB') {
            date_default_timezone_set('Asia/Jakarta');
        } elseif ($lokasi_presensi['zona_waktu'] == 'WITA') {
            date_default_timezone_set('Asia/Makassar');
        } elseif ($lokasi_presensi['zona_waktu'] == 'WIT') {
            date_default_timezone_set('Asia/Jayapura');
        }

        // Query untuk memeriksa apakah siswa mengajukan ketidakhadiran
        // $cek_ketidakhadiran = $this->db->table('ketidakhadiran')
        //     ->where('id_siswa', $id_siswa)
        //     ->countAllResults();

        $ketidakhadiranmodel = new KetidakhadiranModel();
        $cek_ketidakhadiran = $ketidakhadiranmodel->where('id_siswa', $id_siswa)->first();

        // Data yang dikirim ke view
        $data = [
            'title' => 'Home',
            'lokasi_presensi' => $lokasi_presensi,
            'cek_presensi' => $presensi_model->where('id_siswa', $id_siswa)->where('tanggal_masuk', date('Y-m-d'))->countAllResults(),
            'ambil_presensi_masuk' => $presensi_model->where('id_siswa', $id_siswa)->where('tanggal_masuk', date('Y-m-d'))->first(),
            'cek_presensi_keluar' => $presensi_model->where('id_siswa', $id_siswa)->where('tanggal_masuk', date('Y-m-d'))->where('tanggal_keluar != ', '0000-00-00')->countAllResults(),
            'cek_ketidakhadiran' => $cek_ketidakhadiran,
        ];
        // dd($data);
        // Render view 'siswa/home' dengan data
        return view('siswa/home', $data);
    }





    public function presensi_masuk()
    {
        $latitude_siswa = (float) $this->request->getPost('latitude_siswa');
        $latitude_kantor = (float) $this->request->getPost('latitude_kantor');
        $radius = $this->request->getPost('radius');

        $jarak = sin(deg2rad($latitude_siswa)) * sin(deg2rad($latitude_kantor)) + cos(deg2rad($latitude_siswa)) * cos(deg2rad($latitude_kantor));
        $jarak = acos($jarak);
        $jarak = rad2deg($jarak);
        $mil = $jarak * 60 * 1.1515;
        $km = $mil * 1.209344;
        $jarak_meter = floor($km * 1000);
        if ($jarak_meter > $radius) {
            session()->setFlashdata('gagal', 'presensi gagal, lokasi anda berada di luar radius kantor');

            return redirect()->to(base_url('siswa/home'));
        } else {
            $data = [
                'title' => 'Ambil foto Selfie',
                'id_siswa' => $this->request->getPost('id_siswa'),
                'tanggal_masuk' => $this->request->getPost('tanggal_masuk'),
                'jam_masuk' => $this->request->getPost('jam_masuk'),
            ];
            return view('siswa/ambil_foto', $data);
        }
    }


    public function presensi_masuk_aksi()
    {
        $request = \Config\Services::request();
        $id_siswa = $request->getPost('id_siswa');
        $tanggal_masuk = $request->getPost('tanggal_masuk');
        $jam_masuk = $request->getPost('jam_masuk');
        $foto_masuk = $request->getPost('foto_masuk');

        $foto_masuk = str_replace('data:image/jpeg;base64,', '', $foto_masuk);
        $foto_masuk = base64_decode($foto_masuk);

        $foto_dir = 'uploads/' . $id_siswa . '_' . time() . '.jpg';
        $nama_foto = $id_siswa . '_' . time() . '.jpg';
        file_put_contents($foto_dir, $foto_masuk);


        $presensi_model = new PresensiModel();
        $presensi_model->insert([
            'id_siswa' => $id_siswa,
            'tanggal_masuk' => $tanggal_masuk,
            'jam_masuk' => $jam_masuk,
            'foto_masuk' => $nama_foto,
            'paraf' => 'pandding',
            'kegiatan' => '-'
        ]);

        session()->setFlashdata('berhasil', 'Data presensi masuk Berhasil');
        print_r(session()->getFlashdata());  // Debugging untuk memeriksa apakah flashdata di-set
        return redirect()->to(base_url('siswa/home'));
    }


    public function presensi_keluar($id)
    {

        $request = \Config\Services::request();
        $latitude_siswa = (float) $this->request->getPost('latitude_siswa');
        $latitude_kantor = (float) $this->request->getPost('latitude_kantor');
        $radius = $this->request->getPost('radius');
        $jarak = sin(deg2rad($latitude_siswa)) * sin(deg2rad($latitude_kantor)) + cos(deg2rad($latitude_siswa)) * cos(deg2rad($latitude_kantor));
        $jarak = acos($jarak);
        $jarak = rad2deg($jarak);
        $mil = $jarak * 60 * 1.1515;
        $km = $mil * 1.209344;
        $jarak_meter = floor($km * 1000);


        if ($jarak_meter > $radius) {
            session()->setFlashdata('gagal', 'presensi gagal, lokasi anda berada di luar radius kantor');

            return redirect()->to(base_url('siswa/home'));
        } else {
            $data = [
                'title' => 'Ambil foto Selfie',
                'id_presensi' => $id,
                'tanggal_keluar' => $this->request->getPost('tanggal_keluar'),
                'jam_keluar' => $this->request->getPost('jam_keluar'),
            ];
            return view('siswa/ambil_foto_keluar', $data);
        }
    }

    public function presensi_keluar_aksi($id)
    {
        $request = \Config\Services::request();
        $tanggal_keluar = $request->getPost('tanggal_keluar');
        $jam_keluar = $request->getPost('jam_keluar');
        $foto_keluar = $request->getPost('foto_keluar');
        $kegiatan = $request->getPost('kegiatan');


        $foto_keluar = str_replace('data:image/jpeg;base64,', '', $foto_keluar);
        $foto_keluar = base64_decode($foto_keluar);

        $foto_dir = 'uploads/' . $id . '_' . time() . '.jpg';
        $nama_foto = $id . '_' . time() . '.jpg';
        file_put_contents($foto_dir, $foto_keluar);


        $presensi_model = new PresensiModel();
        $presensi_model->update($id, [
            'jam_keluar' => $jam_keluar,
            'tanggal_keluar' => $tanggal_keluar,
            'foto_keluar' => $nama_foto,
            'kegiatan' => $kegiatan,

        ]);

        session()->setFlashdata('berhasil', 'Data presensi keluar  Berhasil');
        return redirect()->to(base_url('siswa/home'));
    }


    public function faq()
    {
        $data = [
            'title' => 'FAQ'
        ];
        return view('siswa/faq', $data);
    }
}
