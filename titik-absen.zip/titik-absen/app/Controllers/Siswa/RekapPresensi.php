<?php

namespace App\Controllers\Siswa;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\PresensiModel;
use App\Models\SiswaModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class RekapPresensi extends BaseController
{
    public function index()
    {
        $presensiModel = new PresensiModel();
        $filter_tanggal = $this->request->getVar('filter_tanggal');

        // Default ambil data presensi untuk hari ini jika tidak ada filter tanggal
        if ($filter_tanggal) {
            $rekap_presensi = $presensiModel->rekap_presensi_siswa_filter($filter_tanggal);
        } else {
            $rekap_presensi = $presensiModel->rekap_presensi_siswa_today(); // Ambil presensi hari ini
        }


        $id_siswa = session()->get('id_siswa');
        $SiswaModel = new SiswaModel();
        // dd($id_siswa);
        // Ambil data siswa berdasarkan id_siswa dari session
        $siswa = $SiswaModel->where('id', $id_siswa)->first();

        // Siapkan data yang akan dikirim ke view
        $data = [
            'title' => 'Rekap Presensi',
            'rekap_presensi' => $rekap_presensi, // Data presensi yang diambil
            'Siswa' => $siswa, // Data siswa
        ];

        // dd($data);
        // Render view dengan data
        return view('siswa/rekap_presensi', $data);
    }


    public function detail_presensi($id)
    {
        $presensiModel = new PresensiModel();
        $SiswaModel = new SiswaModel();
        $id_siswa = session()->get('id_siswa');
        $siswa = $SiswaModel->where('id', $id_siswa)->first();
        $rekap_presensi = $presensiModel->rekap_harian_by_id($id);

        $data = [
            'title' => 'Detail presensi',
            'rekap_presensi' => $rekap_presensi,
            'Siswa' => $siswa
        ];

        // dd($data);

        return view('siswa/detail_harian', $data);
    }
}
