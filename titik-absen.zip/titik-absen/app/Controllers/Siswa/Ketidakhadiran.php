<?php

namespace App\Controllers\Siswa;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\KetidakhadiranModel;
use App\Models\SiswaModel;

class Ketidakhadiran extends BaseController
{
    public function __construct()
    {
        helper(['url', 'form']);
    }

    public function index()
    {
        // Inisialisasi model ketidakhadiran dan siswa
        $ketidakhadiran = new KetidakhadiranModel();
        $siswaModel = new SiswaModel();  // Pastikan Anda memiliki model SiswaModel

        // Mengambil ID siswa dari session
        $id_siswa = session()->get('id_siswa');

        // Cek apakah siswa sudah absen hari ini
        $hasAbsensiToday = $ketidakhadiran->checkAbsensiToday();

        // Ambil data siswa berdasarkan ID siswa di session
        $siswa = $siswaModel->where('id', $id_siswa)->first();  // Ambil data siswa (pertama)

        // Siapkan data untuk dikirim ke view
        $data = [
            'title' => "KetidakHadiran",
            'ketidakhadiran' => $ketidakhadiran->where('id_siswa', $id_siswa)->findAll(),
            'hasAbsensiToday' => $hasAbsensiToday,  // Kirim status absensi ke view
            'nama_siswa' => $siswa['nama']  // Kirim nama siswa ke view
        ];

        // Debug data (opsional, bisa dihapus nanti)
        // dd($data);

        // Kembalikan view dengan data
        return view('siswa/ketidakhadiran', $data);
    }



    public function create()
    {

        $data = [
            'title' => 'Ajukan Ketidakhadiran',
            'validation' => \Config\Services::validation(),

        ];

        // dd($data);

        return view('siswa/create_ketidakhadiran', $data);
    }


    public function store()
    {
        $rules = [
            'keterangan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "keterangan Wajib DI isi",
                ],
            ],
            'tanggal' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Tanggal Wajib DI isi",
                ],
            ],
            'deskripsi' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Deskripsi Wajib DI isi",
                ],
            ],

            'file' => [
                'rules' => 'uploaded[file]|max_size[file,10240 ]|mime_in[file, image/png,image/jpeg, aplication/pdf]',
                'errors' => [
                    'uploaded' => "file wajib di isi",
                    'max_size' => "ukuran foto melebihi 10MB",
                    'mime_in' => "Jenis File Yang Diizinkan Hanya PNG, jpg dan pdf"
                ],
            ],

        ];

        if (!$this->validate($rules)) {
            $data = [
                'title' => 'Ajukan Ketidakhadiran',
                'validation' => \Config\Services::validation()
            ];
            return view('siswa/create_ketidakhadiran', $data);
        } else {
            $ketidakhadiran = new KetidakhadiranModel();

            $file = $this->request->getFile('file');

            if ($file->getError() == 4) {
                $nama_file = '';
            } else {
                $nama_file = $file->getRandomName();
                $file->move('file_ketidakhadiran', $nama_file);
            }

            $ketidakhadiran = new KetidakhadiranModel();
            $ketidakhadiran->insert([
                'keterangan' => $this->request->getPost('keterangan'),
                'tanggal' => $this->request->getPost('tanggal'),
                'id_siswa' => $this->request->getPost('id_siswa'),
                'deskripsi' => $this->request->getPost('deskripsi'),
                'status' => 'pending',
                'file' => $nama_file,
            ]);

            session()->setFlashdata('berhasil', 'ketidakhadiran berhasil di ajukan');

            return redirect()->to(base_url('siswa/ketidakhadiran'));
        }
    }


    public function edit($id)
    {
        $ketidakhadiran = new KetidakhadiranModel();
        $data = [
            'title' => 'Edit ketidakhadiran',
            'ketidakhadiran' => $ketidakhadiran->find($id),
            'validation' => \Config\Services::validation()
        ];

        return view('siswa/edit_ketidakhadiran', $data);
    }


    public function update($id)
    {
        $ketidakhadiran = new KetidakhadiranModel();
        $rules = [
            'keterangan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "keterangan Wajib DI isi",
                ],
            ],
            'tanggal' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Tanggal Wajib DI isi",
                ],
            ],
            'deskripsi' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Deskripsi Wajib DI isi",
                ],
            ],

        ];

        if (!$this->validate($rules)) {
            $ketidakhadiran = new KetidakhadiranModel();
            $data = [
                'title' => 'Edit ketidakhadiran ',
                'ketidakhadiran' => $ketidakhadiran->find($id),
                'validation' => \Config\Services::validation()
            ];

            return view('siswa/edit_ketidakhadiran', $data);
        } else {
            $ketidakhadiran = new KetidakhadiranModel();

            $file = $this->request->getFile('file');
            if ($file->getError() == 4) {
                $nama_file = $this->request->getPost('file_lama');
            } else {
                $nama_file = $file->getRandomName();
                $file->move('file_ketidakhadiran', $nama_file);
            }
            $ketidakhadiran->update($id, [
                'keterangan' => $this->request->getPost('keterangan'),
                'tanggal' => $this->request->getPost('tanggal'),
                'deskripsi' => $this->request->getPost('deskripsi'),
                'status' => 'pending',
                'file' => $nama_file,

            ]);


            session()->setFlashdata('berhasil', 'Data siswa berhasil di update');

            return redirect()->to(base_url('siswa/ketidakhadiran'));
        }
    }



    function delete($id)
    {
        $ketidakhadiranmodel = new KetidakhadiranModel();
        $ketidakhadiran = $ketidakhadiranmodel->find($id);
        if ($ketidakhadiran) {
            $ketidakhadiranmodel->where('id_siswa', $id)->delete();
            $ketidakhadiranmodel->delete($id);
            session()->setFlashdata('berhasil', 'Data ketidakhadiran berhasil di hapus');

            return redirect()->to(base_url('siswa/ketidakhadiran'));
        }
    }
}
