<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\SiswaModel;
use App\Models\UserModel;
use App\Models\LokasiPresensiModel;
use App\Models\JabatanModel;

class Datasiswa extends BaseController
{
    public function __construct()
    {
        helper(['url', 'form']);
    }

    public function index($id)
    {

        $SiswaModel = new SiswaModel();
        $data = [
            'title' => 'Data pengguna',
            'Siswa' => $SiswaModel->findAll(),
        ];



        return view('admin/data_siswa/data_siswa', $data,);
    }

    public function detail($id)
    {
        $SiswaModel = new SiswaModel();
        $data = [
            'title' => 'Detail Siswa',
            'siswa' => $SiswaModel->detailSiswa($id),
        ];

        return view('admin/data_siswa/detail', $data);
    }


    public function create()
    {
        $Lokasi_Presensi = new LokasiPresensiModel();
        $jabatan_model = new JabatanModel();
        $data = [
            'title' => 'Tambah Siswa',
            'lokasi_presensi' => $Lokasi_Presensi->findAll(),
            'jabatan' => $jabatan_model->orderBy('jabatan', 'ASC')->findAll(),
            'validation' => \Config\Services::validation()
        ];
        return view('admin/data_siswa/create', $data);
    }


    // public function generateNisn () 
    // {
    //     $SiswaModel = new SiswaModel();
    //     $siswaTerakhir = $SiswaModel->select('nisn')->orderBy('id', 'DESC')->first();
    //     $nisnTerakhir = $siswaTerakhir ? $siswaTerakhir['nisn'] : 'NISN-00';
    //     $angkaNISN = (int) subStr($nisnTerakhir, 2 );
    //     $angkaNISN++;
    //     return 'NISN-'. str_pad($angkaNISN, 2 ,'0', STR_PAD_LEFT);


    // }


    public function store()
    {
        $rules = [
            'nama' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Nama Wajib DI isi",
                ],
            ],
            'nisn' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "nisn Wajib DI isi",
                ],
            ],
            'jenis_kelamin' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "jenis kelamin Wajib DI isi",
                ],
            ],
            'alamat' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "alamat Wajib DI isi",
                ],
            ],
            'no_hanphone' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "No. Handphone Wajib DI isi",
                ],
            ],
            'jabatan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "jabatan Wajib DI isi",
                ],
            ],
            'lokasi_presensi' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "lokasi presensi Wajib DI isi",
                ],
            ],
            // 'foto_siswa' => [
            //     'rules' => 'uploaded[foto]|max_size[foto,10240]|mime_in[foto,image/png,image/jpeg]',
            //     'errors' => [
            //         'uploaded' => "Foto wajib diisi.",
            //         'max_size' => "Ukuran foto melebihi 10MB.",
            //         'mime_in' => "Jenis file yang diizinkan hanya PNG atau JPEG."
            //     ],
            // ],
            'username' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Username Wajib DI isi",
                ],
            ],
            'password' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Password Wajib DI isi",
                ],
            ],
            'konfirmasi_password' => [
                'rules' => 'required|matches[password]',
                'errors' => [
                    'required' => "Konfirmasi Password Wajib DI isi",
                    'matches'  => "Password tidak sesuai"
                ],
            ],
            'role' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "role Wajib DI isi",
                ],
            ],
        ];

        if (!$this->validate($rules)) {
            $Lokasi_Presensi = new LokasiPresensiModel();
            $jabatan_model = new JabatanModel();
            $data = [
                'title' => 'Tambah Siswa',
                'lokasi_presensi' => $Lokasi_Presensi->findAll(),
                'jabatan' => $jabatan_model->findAll(),
                'validation' => \Config\Services::validation()
            ];
            echo view('admin/data_siswa/create', $data);
        } else {
            $SiswaModel = new SiswaModel();
            // $nisnBaru = $this->generateNisn();

            $foto = $this->request->getFile('foto_siswa');

            if ($foto->getError() == 4) {
                $nama_foto = '';
            } else {
                $nama_foto = $foto->getRandomName();
                $foto->move('profile', $nama_foto);
            }

            $SiswaModel = new SiswaModel();
            $SiswaModel->insert([
                'nisn' =>  $this->request->getPost('nisn'),
                'nama' => $this->request->getPost('nama'),
                'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
                'alamat' => $this->request->getPost('alamat'),
                'no_hanphone' => $this->request->getPost('no_hanphone'),
                'jabatan' => $this->request->getPost('jabatan'),
                'lokasi_presensi' => $this->request->getPost('lokasi_presensi'),
                'foto_siswa' => $nama_foto,
            ]);


            $id_siswa = $SiswaModel->insertID();
            $userModel = new UserModel();
            $userModel->insert([
                'id_siswa' => $id_siswa,
                'username' => $this->request->getPost('username'),
                'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
                'status' => 'Aktif',
                'role' => $this->request->getPost('role'),
            ]);


            session()->setFlashdata('berhasil', 'Data siswa Presensi berhasil tersimpan');

            return redirect()->to(base_url('admin/data_siswa'));
        }
    }

    public function edit($id)
    {
        $Lokasi_Presensi = new LokasiPresensiModel();
        $jabatan_model = new JabatanModel();
        $siswaModel = new siswaModel();

        $data = [
            'title' => 'Edit Data Siswa',
            'siswa' => $siswaModel->editSiswa($id),
            'lokasi_presensi' => $Lokasi_Presensi->findAll(), // Kunci: 'lokasi_presensi'
            'jabatan' => $jabatan_model->orderBy('jabatan', 'ASC')->findAll(),
            'validation' => \Config\Services::validation()
        ];

        return view('admin/data_siswa/edit', $data);
    }


    public function update($id)
    {
        $SiswaModel = new SiswaModel();
        $rules = [
            'nama' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Nama Wajib DI isi",
                ],
            ],
            'nisn' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "nisn Wajib DI isi",
                ],
            ],
            'jenis_kelamin' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "jenis kelamin Wajib DI isi",
                ],
            ],
            'alamat' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "alamat Wajib DI isi",
                ],
            ],
            'no_hanphone' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "No. Handphone Wajib DI isi",
                ],
            ],
            'jabatan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "jabatan Wajib DI isi",
                ],
            ],
            'lokasi_presensi' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "lokasi presensi Wajib DI isi",
                ],
            ],
            // 'foto_siswa' => [
            //     'rules' => 'uploaded[foto]|max_size[foto,10240]|mime_in[foto,image/png,image/jpeg]',
            //     'errors' => [
            //         'uploaded' => "Foto wajib diisi.",
            //         'max_size' => "Ukuran foto melebihi 10MB.",
            //         'mime_in' => "Jenis file yang diizinkan hanya PNG atau JPEG."
            //     ],
            // ],

            'username' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Username Wajib DI isi",
                ],
            ],
            'role' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "role Wajib DI isi",
                ],
            ],
        ];
        if (!$this->validate($rules)) {
            $Lokasi_Presensi = new LokasiPresensiModel();
            $jabatan_model = new JabatanModel();
            $siswaModel = new siswaModel();
            $data = [
                'title' => 'Edit siswa ',
                'siswa' => $siswaModel->editSiswa($id),
                'lokasi_presensi' => $Lokasi_Presensi->findAll(),
                'jabatan' => $jabatan_model->orderBy('jabatan', 'ASC')->findAll(),
                'validation' => \Config\Services::validation()
            ];

            return view('admin/data_siswa/edit', $data);
        } else {
            $SiswaModel = new SiswaModel();
            $foto = $this->request->getFile('foto_siswa');
            if ($foto->getError() == 4) {
                $nama_foto = $this->request->getPost('foto_lama');
            } else {
                $nama_foto = $foto->getRandomName();
                $foto->move('profile', $nama_foto);
            }
            $SiswaModel->update($id, [
                'nama' => $this->request->getPost('nama'),
                'nisn' => $this->request->getPost('nisn'),
                'jenis_kelamin' => $this->request->getPost('jenis_kelamin'),
                'alamat' => $this->request->getPost('alamat'),
                'no_hanphone' => $this->request->getPost('no_hanphone'),
                'jabatan' => $this->request->getPost('jabatan'),
                'lokasi_presensi' => $this->request->getPost('lokasi_presensi'),
                'foto_siswa' => $nama_foto,

            ]);


            session()->setFlashdata('berhasil', 'Data siswa berhasil di update');

            return redirect()->to(base_url('admin/data_siswa'));
        }
    }



    function delete($id)
    {
        $SiswaModel = new SiswaModel();
        $userModel = new UserModel();
        $siswa = $SiswaModel->find($id);
        if ($siswa) {
            $userModel->where('id_siswa', $id)->delete();
            $SiswaModel->delete($id);
            session()->setFlashdata('berhasil', 'Data Siswa berhasil di hapus');

            return redirect()->to(base_url('admin/data_siswa'));
        }
    }
}
