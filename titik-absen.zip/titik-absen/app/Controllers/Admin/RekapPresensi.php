<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\PresensiModel;
use App\Models\SiswaModel;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Predis\Command\Argument\Server\To;

class RekapPresensi extends BaseController

{

    public function __construct()
    {
        helper(['url', 'form']);
    }

    public function rekap_harian($id)
    {
        $presensi_model = new PresensiModel();
        $filter_tanggal = $this->request->getVar('filter_tanggal');
        $rekap_harian = $presensi_model->rekap_harian();
        if ($filter_tanggal) {
            if (isset($_GET['excel'])) {
                $rekap_harian = $presensi_model->rekap_harian_filter($filter_tanggal);
                $spreadsheet = new Spreadsheet();
                $activeWorksheet = $spreadsheet->getActiveSheet();

                $spreadsheet->getActiveSheet()->mergeCells('A1:C1');
                $spreadsheet->getActiveSheet()->mergeCells('A3:B3');
                $spreadsheet->getActiveSheet()->mergeCells('C3:E3');

                $activeWorksheet->setCellValue('A1', 'REKAP PRESENSI HARIAN');
                $activeWorksheet->setCellValue('A3', 'TANGGAL');
                $activeWorksheet->setCellValue('C3', $filter_tanggal);
                $activeWorksheet->setCellValue('A4', 'NO');
                $activeWorksheet->setCellValue('B4', 'NAMA SISWA');
                $activeWorksheet->setCellValue('C4', 'TANGGAL MASUK');
                $activeWorksheet->setCellValue('D4', 'JAM MASUK');
                $activeWorksheet->setCellValue('E4', 'TANGGAL KELUAR');
                $activeWorksheet->setCellValue('F4', 'JAM KELUAR');
                $activeWorksheet->setCellValue('G4', 'TOTAL JAM KETERLAMBATAN');
                $activeWorksheet->setCellValue('H4', 'KEGIATAN');
                $activeWorksheet->setCellValue('I4', 'STATUS');
                $rows = 5;
                $no = 1;

                foreach ($rekap_harian as $rekap) {
                    //menghitung jumlah jam kerja
                    $timestamp_jam_masuk = strtotime($rekap['tanggal_masuk'] . $rekap['jam_masuk']);
                    $timestamp_jam_keluar = strtotime($rekap['tanggal_keluar'] . $rekap['jam_keluar']);
                    $selisih = $timestamp_jam_keluar - $timestamp_jam_masuk;
                    $jam = floor($selisih / 3600);
                    $selisih -= $jam * 3600;
                    $menit = floor($selisih / 60);


                    // menghitung jumblah jam keterlambatan 
                    $jam_masuk_real = strtotime($rekap['jam_masuk']);
                    $jam_masuk_kantor = strtotime($rekap['jam_masuk_kantor']);
                    $selisih_terlambat = $jam_masuk_real - $jam_masuk_kantor;
                    $jam_terlambat = floor($selisih_terlambat / 3600);
                    $selisih_terlambat -= $jam_terlambat * 3600;
                    $menit_terlambat = floor($selisih_terlambat / 60);


                    $activeWorksheet->setCellValue('A' . $rows, $no++);
                    $activeWorksheet->setCellValue('B' . $rows, $rekap['nama']);
                    $activeWorksheet->setCellValue('C' . $rows, $rekap['tanggal_masuk']);
                    $activeWorksheet->setCellValue('D' . $rows, $rekap['jam_masuk']);
                    $activeWorksheet->setCellValue('E' . $rows, $rekap['tanggal_keluar']);
                    $activeWorksheet->setCellValue('F' . $rows, $rekap['jam_keluar']);
                    $activeWorksheet->setCellValue('G' . $rows, $jam_terlambat . ' jam ' . $menit_terlambat . ' menit ');
                    $activeWorksheet->setCellValue('H' . $rows, $rekap['kegiatan']);
                    $activeWorksheet->setCellValue('I' . $rows, $rekap['paraf']);
                    $rows++;
                }

                // redirect output to client browser
                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header('Content-Disposition: attachment;filename="rekap_presensi_harian.xlsx"');
                header('Cache-Control: max-age=0');

                $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($spreadsheet, 'Xlsx');
                $writer = new Xlsx($spreadsheet);
                $writer->save('php://output');
            } else {
                $rekap_harian = $presensi_model->rekap_harian_filter($filter_tanggal);
            }
        } else {
        }


        $paraf = new PresensiModel();
        $id_siswa = session()->get('id_siswa');
        $SiswaModel = new SiswaModel();
        $data = [
            'title' => 'Rekap Harian',
            'tanggal' => $filter_tanggal,
            'rekap_harian' => $rekap_harian,
            'paraf' => $paraf->where('id_siswa', $id_siswa)->findAll(),
            'Siswa' => $SiswaModel->findAll(),

        ];

        // dd($data);
        return view('admin/rekap_presensi/rekap_harian', $data);
    }

    public function rekap_bulanan()
    {
        $presensi_model = new PresensiModel();
        $filter_bulan = $this->request->getVar('filter_bulan');
        $filter_tahun = $this->request->getVar('filter_tahun');

        if ($filter_bulan) {

            if (isset($_GET['excel'])) {
                $rekap_bulanan = $presensi_model->rekap_bulanan_filter($filter_bulan, $filter_tahun);
                $spreadsheet = new Spreadsheet();
                $activeWorksheet = $spreadsheet->getActiveSheet();

                $spreadsheet->getActiveSheet()->mergeCells('A1:C1');
                $spreadsheet->getActiveSheet()->mergeCells('A3:B3');
                $spreadsheet->getActiveSheet()->mergeCells('C3:E3');

                $activeWorksheet->setCellValue('A1', 'REKAP PRESENSI BULANAN');
                $activeWorksheet->setCellValue('A3', 'BULAN');
                $activeWorksheet->setCellValue('C3', date('F Y', strtotime($filter_tahun . '-' . $filter_bulan)));
                $activeWorksheet->setCellValue('A4', 'NO');
                $activeWorksheet->setCellValue('B4', 'NAMA SISWA');
                $activeWorksheet->setCellValue('C4', 'TANGGAL MASUK');
                $activeWorksheet->setCellValue('D4', 'JAM MASUK');
                $activeWorksheet->setCellValue('E4', 'TANGGAL KELUAR');
                $activeWorksheet->setCellValue('F4', 'JAM KELUAR');
                $activeWorksheet->setCellValue('G4', 'TOTAL JAM KETERLAMBATAN');
                $activeWorksheet->setCellValue('H4', 'KEGIATAN');
                $activeWorksheet->setCellValue('I4', 'STATUS');

                $rows = 5;
                $no = 1;

                foreach ($rekap_bulanan as $rekap) {
                    //menghitung jumlah jam kerja
                    $timestamp_jam_masuk = strtotime($rekap['tanggal_masuk'] . $rekap['jam_masuk']);
                    $timestamp_jam_keluar = strtotime($rekap['tanggal_keluar'] . $rekap['jam_keluar']);
                    $selisih = $timestamp_jam_keluar - $timestamp_jam_masuk;
                    $jam = floor($selisih / 3600);
                    $selisih -= $jam * 3600;
                    $menit = floor($selisih / 60);


                    // menghitung jumblah jam keterlambatan 
                    $jam_masuk_real = strtotime($rekap['jam_masuk']);
                    $jam_masuk_kantor = strtotime($rekap['jam_masuk_kantor']);
                    $selisih_terlambat = $jam_masuk_real - $jam_masuk_kantor;
                    $jam_terlambat = floor($selisih_terlambat / 3600);
                    $selisih_terlambat -= $jam_terlambat * 3600;
                    $menit_terlambat = floor($selisih_terlambat / 60);


                    $activeWorksheet->setCellValue('A' . $rows, $no++);
                    $activeWorksheet->setCellValue('B' . $rows, $rekap['nama']);
                    $activeWorksheet->setCellValue('C' . $rows, $rekap['tanggal_masuk']);
                    $activeWorksheet->setCellValue('D' . $rows, $rekap['jam_masuk']);
                    $activeWorksheet->setCellValue('E' . $rows, $rekap['tanggal_keluar']);
                    $activeWorksheet->setCellValue('F' . $rows, $rekap['jam_keluar']);
                    $activeWorksheet->setCellValue('G' . $rows, $jam_terlambat . ' jam ' . $menit_terlambat . ' menit ');
                    $activeWorksheet->setCellValue('H' . $rows, $rekap['kegiatan']);
                    $activeWorksheet->setCellValue('I' . $rows, $rekap['paraf']);
                    $rows++;
                }

                // redirect output to client browser
                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header('Content-Disposition: attachment;filename="rekap_presensi_bulanan.xlsx"');
                header('Cache-Control: max-age=0');

                $writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($spreadsheet, 'Xlsx');
                $writer = new Xlsx($spreadsheet);
                $writer->save('php://output');
            } else {
                $rekap_bulanan = $presensi_model->rekap_bulanan_filter($filter_bulan, $filter_tahun);
            }
        } else {
            $rekap_bulanan = $presensi_model->rekap_bulanan();
        }

        $SiswaModel = new SiswaModel();
        $data = [
            'title' => 'Rekap Bulanan',
            'bulan' => $filter_bulan,
            'tahun' => $filter_tahun,
            'rekap_bulanan' => $rekap_bulanan,
            'Siswa' => $SiswaModel->findAll(),
        ];

        // dd($data);
        return view('admin/rekap_presensi/rekap_bulanan', $data);
    }

    public function parafharian($id)
    {
        $paraf = new PresensiModel();
        $paraf->update($id, [
            'paraf' => 'parafed'
        ]);

        if (!$paraf) {
            // Tampilkan error atau log jika gagal
            echo $paraf->errors();
        }

        session()->setFlashdata('berhasil', 'Absensi berhasil di paraf');
        return redirect()->to(base_url('admin/rekap_harian'));
    }

    public function parafbulan($id)
    {
        $paraf = new PresensiModel();
        $paraf->update($id, [
            'paraf' => 'parafed'
        ]);

        session()->setFlashdata('berhasil', 'Absensi berhasil di paraf');
        return redirect()->to(base_url('admin/rekap_bulanan'));
    }


    public function detail_harian($id)
    {
        $presensi_model = new PresensiModel();
        $SiswaModel = new SiswaModel();

        // Ambil filter tanggal dari request
        $filter_tanggal = $this->request->getVar('filter_tanggal');

        // $filter_tanggal = $this->global_tanggal;

        if ($filter_tanggal) {
            $rekap_harian = $presensi_model->rekap_harian_filter_id($filter_tanggal, $id);
        } else {
            $rekap_harian = $presensi_model->rekap_harian_by_id($id);
        }

        // Kirimkan data ke view
        $data = [
            'title' => 'Detail Absen Harian',
            'rekap_harian' => $rekap_harian,
            'Siswa' => $SiswaModel->findAll(),
            'tanggal' => $filter_tanggal, // Kirim tanggal yang difilter (jika ada)
        ];

        // dd($data);
        return view('admin/detail_presensi/detail_harian', $data);
    }



    public function detail_bulanan($id)
    {
        $presensi_model = new PresensiModel();
        $SiswaModel = new SiswaModel();
        $filter_bulan = $this->request->getVar('filter_bulan');
        $filter_tahun = $this->request->getVar('filter_tahun');

        if ($filter_bulan) {
            $rekap_bulanan = $presensi_model->rekap_bulanan_filter_id($filter_bulan, $filter_tahun, $id);
        } else {
            $rekap_bulanan = $presensi_model->rekap_bulanan_by_id($id);
        }

        $data = [
            'title' => 'Detail Absen Bulanan',
            'bulan' => $filter_bulan,
            'tahun' => $filter_tahun,
            'rekap_bulanan' => $rekap_bulanan,
            'Siswa' => $SiswaModel->findAll(),
        ];
        // dd($data);
        return view('admin/detail_presensi/detail_bulanan', $data);
    }
}
