<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\LokasiPresensiModel;

class LokasiPresensi extends BaseController
{
    public function index()
    {
        
        $LokasiPresensiModel = new LokasiPresensiModel();
        $data = [
            'title' => 'Data Lokasi Presensi',
            'lokasi_presensi' => $LokasiPresensiModel->findAll()
        ];

        return view('admin/lokasi_presensi/lokasi_presensi', $data);
    }

    public function detail($id)
    {
        $LokasiPresensiModel = new LokasiPresensiModel();
        $data =[
            'title' => 'Detail lokasi Presensi',
            'lokasi_presensi' => $LokasiPresensiModel->find($id),
        ];
        return view('admin/lokasi_presensi/detail', $data);
    }


    public function create() {
        $data = [
            'title' => 'Tambah Lokasi Presensi',
            'validation' => \Config\Services::validation()
        ];
        return view('admin/lokasi_presensi/create' , $data);
    }


    public function store () {
        $rules = [
            'nama_lokasi' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Nama lokasi Wajib DI isi",
                ],
            ],
            'alamat_lokasi' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Alamat lokasi Wajib DI isi",
                ],
            ],
            'tipe_lokasi' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Tipe lokasi Wajib DI isi",
                ],
            ],
            'latitude' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "latitude Wajib DI isi",
                ],
            ],
            'longitude' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Longitude Wajib DI isi",
                ],
            ],
            'radius' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Radius Wajib DI isi",
                ],
            ],
            'zona_waktu' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Zona_waktu Wajib DI isi",
                ],
            ],
            'jam_masuk' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Jam_masuk Wajib DI isi",
                ],
            ],
            'jam_pulang' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Jam_pulang Wajib DI isi",
                ],
            ],
        ];

        if(!$this->validate($rules)) {
            $data = [
                'title' => 'Tmbah lokasi Presensi',
                'validation' => \Config\Services::validation()
            ];
            echo view('admin/lokasi_presensi/create', $data);
        }else{
            $LokasiPresensiModel = new LokasiPresensiModel();
            $LokasiPresensiModel -> insert([
                'nama_lokasi' => $this->request->getPost('nama_lokasi'),
                'alamat_lokasi' => $this->request->getPost('alamat_lokasi'),
                'tipe_lokasi' => $this->request->getPost('tipe_lokasi'),
                'latitude' => $this->request->getPost('latitude'),
                'longitude' => $this->request->getPost('longitude'),
                'radius' => $this->request->getPost('radius'),
                'zona_waktu' => $this->request->getPost('zona_waktu'),
                'jam_masuk' => $this->request->getPost('jam_masuk'),
                'jam_pulang' => $this->request->getPost('jam_pulang'),
            ]);

            session()->setFlashdata('berhasil', 'Data Lokasi Presensi berhasil tersimpan');

            return redirect()->to(base_url('admin/lokasi_presensi')); 
        }
    }

    public function edit($id) {
        $LokasiPresensiModel = new LokasiPresensiModel();
        $data = [
            'title' => 'Edit Lokasi Presensi',
            'lokasi_presensi' => $LokasiPresensiModel->find($id),
            'validation' => \Config\Services::validation()
        ];
        return view('admin/lokasi_presensi/edit' , $data);
    }


    public function update ($id) {
        $LokasiPresensiModel = new LokasiPresensiModel();
        $rules = [
            'nama_lokasi' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Nama lokasi Wajib DI isi",
                ],
            ],
            'alamat_lokasi' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Alamat lokasi Wajib DI isi",
                ],
            ],
            'tipe_lokasi' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Tipe lokasi Wajib DI isi",
                ],
            ],
            'latitude' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "latitude Wajib DI isi",
                ],
            ],
            'longitude' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Longitude Wajib DI isi",
                ],
            ],
            'radius' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Radius Wajib DI isi",
                ],
            ],
            'zona_waktu' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Zona_waktu Wajib DI isi",
                ],
            ],
            'jam_masuk' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Jam_masuk Wajib DI isi",
                ],
            ],
            'jam_pulang' => [
                'rules' => 'required',
                'errors' => [
                    'required' => "Jam_pulang Wajib DI isi",
                ],
            ],
        ];
        if(!$this->validate($rules)) {
            $data = [
                'title' => 'Edit Lokasi Presensi',
                'lokasi_presensi' => $LokasiPresensiModel->find($id),
                'validation' => \Config\Services::validation()
            ];
        return view('admin/lokasi_presensi/edit' , $data);
        } else {
            $LokasiPresensiModel = new LokasiPresensiModel();
            $LokasiPresensiModel -> update($id, [
                'nama_lokasi' => $this->request->getPost('nama_lokasi'),
                'alamat_lokasi' => $this->request->getPost('alamat_lokasi'),
                'tipe_lokasi' => $this->request->getPost('tipe_lokasi'),
                'latitude' => $this->request->getPost('latitude'),
                'longitude' => $this->request->getPost('longitude'),
                'radius' => $this->request->getPost('radius'),
                'zona_waktu' => $this->request->getPost('zona_waktu'),
                'jam_masuk' => $this->request->getPost('jam_masuk'),
                'jam_pulang' => $this->request->getPost('jam_pulang'),
                
            ]);

            session()->setFlashdata('berhasil', 'Data Lokasi berhasil di update');

            return redirect()->to(base_url('admin/lokasi_presensi')); 
        }
    }



    function delete($id)
    {
        $LokasiPresensiModel = new LokasiPresensiModel();

        $LokasiPresensi = $LokasiPresensiModel->find($id);
        if($LokasiPresensi) {
            $LokasiPresensiModel->delete($id);
            session()->setFlashdata('berhasil', 'Data lokasi berhasil di hapus');

            return redirect()->to(base_url('admin/lokasi_presensi')); 
        }
    } 
}
