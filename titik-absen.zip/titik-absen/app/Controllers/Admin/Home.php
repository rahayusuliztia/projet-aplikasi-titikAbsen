<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\KetidakhadiranModel;
use App\Models\PresensiModel;
use App\Models\SiswaModel;
use CodeIgniter\HTTP\ResponseInterface;


class Home extends BaseController
{


    public function index()
    {
        date_default_timezone_set('Asia/Jakarta');
        $siswa_model = new SiswaModel();
        $presensi_model = new  PresensiModel();
        $Ketidakhadiran_model = new KetidakhadiranModel();
        $id_siswa = session()->get('id_siswa');
        $siswa = $siswa_model->where('id', $id_siswa)->first();


        $session = session();
        $session_foto = [
            'foto' => $siswa['foto_siswa'], // Pastikan $siswa adalah array hasil dari query
        ];


        // reset tabel ketidakhadiran 
        $this->checkAndReset();
        // cek absen pulang
        $this->cek_absen();


        $session->set($session_foto);
        $data = [
            'title' => 'Home',
            'total_siswa' => $siswa_model->countAllResults(),
            'total_hadir' => $presensi_model->where('tanggal_masuk', date('Y-m-d'))->countAllResults(),
            'ketidakhadiran' => $Ketidakhadiran_model->where('tanggal', date('Y-m-d'))->countAllResults(),
            'tanggal' => $this->global_tanggal, // Menambahkan tanggal dari BaseController

        ];
        // dd($data);
        return view('admin/home', $data);
    }


    // fungsi reset ketidakhadiran 
    private function checkAndReset()
    {
        $db = \Config\Database::connect(); // Koneksi ke database

        // Mengambil waktu terakhir reset dari tabel log_reset
        $query = $db->query("SELECT last_reset FROM log_reset ORDER BY id DESC LIMIT 1");
        $row = $query->getRow();

        $lastReset = $row ? $row->last_reset : null;
        $currentDate = date('Y-m-d'); // Tanggal hari ini (tanpa waktu)
        $midnight = date('Y-m-d 00:00:00'); // Jam 12 malam hari ini

        // Jika belum pernah dilakukan reset, atau reset terakhir dilakukan pada hari yang berbeda
        if ($lastReset == null || date('Y-m-d', strtotime($lastReset)) != $currentDate) {
            // Hapus data ketidakhadiran yang lebih lama dari jam 12 malam hari ini
            $model = new KetidakhadiranModel();
            $model->where('created_at <', $midnight)->delete(); // Hanya menghapus data sebelum jam 12 malam

            // Simpan waktu reset saat ini ke dalam tabel log_reset
            $db->query("INSERT INTO log_reset (last_reset) VALUES (NOW())");
        }
    }



    private function cek_absen()
    {
        // Load model database
        $db = \Config\Database::connect();

        // Buat query untuk mencari semua presensi dengan jam_keluar = '00:00:00'
        $builder = $db->table('presensi');
        $builder->where('jam_keluar', '00:00:00');

        // Ambil semua data yang memenuhi kriteria
        $query = $builder->get();
        $results = $query->getResult();

        // Atur timezone Asia/Jakarta
        $timezone = new \DateTimeZone('Asia/Jakarta');

        foreach ($results as $row) {
            // Ambil nilai jam_masuk dari database
            $jam_masuk = new \DateTime($row->jam_masuk, $timezone);

            // Tambahkan 12 jam dari jam_masuk
            $jam_masuk_plus_12 = clone $jam_masuk;
            $jam_masuk_plus_12->modify('+12 hours');

            // Dapatkan waktu saat ini
            $now = new \DateTime('now', $timezone);

            // Jika sudah lebih dari 12 jam sejak jam_masuk
            if ($now >= $jam_masuk_plus_12) {
                // Update kolom paraf menjadi 'alfa' untuk semua yang memenuhi kondisi
                $builder->where('jam_keluar', '00:00:00'); // Pastikan jam_keluar masih '00:00:00'
                $builder->update(['paraf' => 'alfa']);
            }
        }
    }
}
