<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\KetidakhadiranModel;

class Ketidakhadiran extends BaseController
{
    public function index()
    {
        $ketidakhadiran_model = new KetidakhadiranModel();
        $ketidakhadiran = $ketidakhadiran_model->ketidakhadiran();
        $data = [
            'title' => "KetidakHadiran",
            'ketidakhadiran' => $ketidakhadiran
        ];

        // dd($data);
        return view('admin/ketidakhadiran', $data);
    }

    public function approved($id)
    {
        $ketidakhadiran_model = new KetidakhadiranModel();
        $ketidakhadiran_model->update($id, [
            'status' => 'Approved'
        ]);


        session()->setFlashdata('berhasil', 'Status pengajuan ketidakhadiran berhasil di Approved');
        return redirect()->to(base_url('admin/ketidakhadiran'));
    }


    public function delete($id)
    {
        $ketidakhadiran_model = new KetidakhadiranModel();
        $ketidakhadiran_model->delete($id);
        session()->setFlashdata('berhasil', 'data berhasil di hapus');

        return redirect()->to(base_url('admin/ketidakhadiran'));
    }
}
