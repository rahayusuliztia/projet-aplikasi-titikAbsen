<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class PegawaiFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
       if(!session()->get('loged_in')) {
        session()->setFlashdata('Pesan', 'Anda belum login');
        return redirect()->to('/');
       }

       if(session()->get('role_id') != 'siswa') {
        session()->setFlashdata('pesan', 'Anda belum login');
        return redirect()->to('/');
       }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do something here
    }
}