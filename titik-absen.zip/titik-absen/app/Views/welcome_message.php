<?= $this->extend('layout.php') ?>

<?= $this->section('Content') ?>
    <h1>sidik ganteng</h1>
<?= $this->endSection() ?>