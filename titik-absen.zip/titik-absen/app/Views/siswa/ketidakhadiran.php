<?= $this->extend('siswa/layout.php') ?>

<?= $this->section('Content') ?>

<style>
    .disabled-link {
        pointer-events: none;
        opacity: 0.5;
        cursor: not-allowed;
    }

    @media (max-width: 768px) {

        /* Menyesuaikan ukuran tombol dan teks pada perangkat mobile */
        .btn {
            width: 100%;
            margin-bottom: 10px;
        }

        table {
            font-size: 12px;
        }

        .table th,
        .table td {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
    }
</style>

<?php
date_default_timezone_set('Asia/Jakarta');
$currentHour = date('H');
$isWithinAllowedTime = ($currentHour >= 6 && $currentHour <= 18);
?>

<?php if (!$hasAbsensiToday): ?>
    <?php if ($isWithinAllowedTime): ?>
        <a href="<?= base_url('siswa/ketidakhadiran/create') ?>" class="btn btn-primary">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-circle-plus">
                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                <path d="M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0" />
                <path d="M9 12h6" />
                <path d="M12 9v6" />
            </svg>
            Ajukan
        </a>
    <?php else: ?>
        <div class="alert alert-warning">Pengajuan ketidakhadiran hanya dapat dilakukan antara jam 6 pagi hingga 6 sore.</div>
    <?php endif; ?>
<?php else: ?>
    <div class="alert alert-info">Anda sudah melakukan absensi hari ini, tidak perlu mengajukan ketidakhadiran.</div>
<?php endif; ?>

<!-- Membungkus tabel dengan table-responsive untuk membuatnya responsif -->
<div class="table-responsive">
    <table class="table table-striped" id="datatables">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Tanggal</th>
                <th>Keterangan</th>
                <th>Deskripsi</th>
                <th>File</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <?php if ($ketidakhadiran) : ?>
            <tbody>
                <?php $no = 1;
                foreach ($ketidakhadiran as $item) : ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $nama_siswa ?></td>
                        <td><?= $item['tanggal'] ?></td>
                        <td><?= $item['keterangan'] ?></td>
                        <td><?= $item['deskripsi'] ?></td>
                        <td>
                            <a class="badge bg-primary" href="<?= base_url('file_ketidakhadiran/' . $item['file']) ?>">Download</a>
                        </td>
                        <td class="<?= $item['status'] === 'pending' ? 'text-danger' : 'text-success' ?>">
                            <?= htmlspecialchars($item['status']) ?>
                        </td>

                        <td>
                            <a href="<?= $item['status'] === 'pending' ? base_url('siswa/ketidakhadiran/edit/' . $item['id']) : '#' ?>"
                                class="badge bg-primary <?= $item['status'] !== 'pending' ? 'disabled-link' : '' ?>"
                                <?= $item['status'] !== 'pending' ? 'tabindex="-1"' : '' ?>>
                                Edit
                            </a>

                            <a href="<?= $item['status'] === 'pending' ? base_url('siswa/ketidakhadiran/delete/' . $item['id']) : '#' ?>"
                                class="badge bg-danger <?= $item['status'] !== 'pending' ? 'disabled-link' : '' ?>"
                                <?= $item['status'] !== 'pending' ? 'tabindex="-1"' : '' ?>>
                                Delete
                            </a>
                        </td>

                    </tr>
                <?php endforeach; ?>
            </tbody>
        <?php else : ?>
            <tbody>
                <tr class="text-center">
                    <td colspan="8">Data masih kosong</td>
                </tr>
            </tbody>
        <?php endif; ?>
    </table>
</div>

<?= $this->endSection() ?>