<?= $this->extend('siswa/layout.php') ?>

<?= $this->section('Content') ?>


<div class="d-flex ">
    <div class="card" style="width: 18rem;">
        <div class="card-body">
            <h5 class="card-title mb-5">Apa itu titik absen?</h5>
            <p class="card-text">Aplikasi Titik Absen adalah sebuah sistem absensi berbasis web yang memungkinkan pengguna untuk mencatat kehadiran dengan menggunakan foto saat masuk dan keluar.</p>
        </div>
    </div>
    <div class="card mx-2" style="width: 18rem;">
        <div class="card-body">
            <h5 class="card-title mb-5">Bagaimana cara mendaftar di aplikasi Titik Absen?</h5>
            <p class="card-text">Pengguna dapat mendaftar melalui formulir pendaftaran yang disediakan oleh admin sekolah. Setelah data diinput, pengguna akan menerima kredensial untuk login..</p>
        </div>
    </div>
    <div class="card" style="width: 18rem;">
        <div class="card-body">
            <h5 class="card-title mb-5">Apakah data kehadiran bisa diunduh?</h5>
            <p class="card-text">Ya, aplikasi Titik Absen menyediakan fitur ekspor data kehadiran ke format CSV atau Excel, sehingga pengguna dapat mengunduh dan menganalisis data kehadiran.</p>
        </div>
    </div>
</div>
<?= $this->endSection() ?>