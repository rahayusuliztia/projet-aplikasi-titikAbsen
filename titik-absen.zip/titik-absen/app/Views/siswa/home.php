<?= $this->extend('siswa/layout.php') ?>

<?= $this->section('Content') ?>
<!-- ========== title-wrapper end ========== -->

<style>
  .parent-clock {
    display: grid;
    grid-template-columns: auto auto auto auto auto;
    font-size: 35px;
    font-weight: bold;
    justify-content: center;

  }

  /* Atur ukuran map menjadi responsif */
  #map {
    width: 100%;
    /* Lebar penuh sesuai dengan elemen induknya */
    height: 400px;
    /* Anda dapat mengatur tinggi sesuai kebutuhan */
    max-width: 100%;
    background-color: lightgray;
    /* Hanya sebagai placeholder jika map tidak ada */
  }

  @media (max-width: 600px) {

    /* Aturan CSS untuk layar yang lebih kecil */
    #map {
      height: 300px;
      /* Sesuaikan tinggi pada layar kecil */
    }
  }
</style>


<div class="row mb-3">
  <div class="col-md-2"></div>
  <div class="col-md-4">
    <div class="card h-100">
      <div class="card-header">Absensi Masuk</div>

      <?php if (isset($cek_ketidakhadiran['status']) && $cek_ketidakhadiran['status'] == 'pending') : ?>
        <div class="card-body text-center">
          <p class="text-danger">Anda sedang mengajukan ketidakhadiran, absensi tidak dapat dilakukan.</p>
        </div>

      <?php elseif (isset($cek_ketidakhadiran['status']) && $cek_ketidakhadiran['status'] == 'Approved') : ?>
        <div class="card-body text-center">
          <p class="text-success">Ketidakhadiran anda sudah di terima</p>
        </div>

      <?php elseif (!isset($cek_presensi) || $cek_presensi < 1) : ?>
        <div class="card-body text-center">
          <div class="fw-bold"><?= date('d F Y ') ?></div>
          <div class="parent-clock">
            <div id="jam-masuk"></div>
            <div>:</div>
            <div id="menit-masuk"></div>
            <div>:</div>
            <div id="detik-masuk"></div>
          </div>

          <form method="post" action="<?= base_url('siswa/presensi_masuk') ?> ">
            <?php
            if ($lokasi_presensi['zona_waktu'] == 'WIB') {
              date_default_timezone_set('Asia/Jakarta');
            } elseif ($lokasi_presensi['zona_waktu'] == 'WITA') {
              date_default_timezone_set('Asia/Makassar');
            } elseif ($lokasi_presensi['zona_waktu'] == 'WIT') {
              date_default_timezone_set('Asia/Jayapura');
            }

            // Validasi waktu absensi masuk
            $current_time = date('H:i:s');
            $start_time = '06:00:00';
            $end_time = '18:00:00';
            ?>

            <input type="hidden" name="latitude_kantor" value="<?= $lokasi_presensi['latitude'] ?>">
            <input type="hidden" name="longitude_kantor" value="<?= $lokasi_presensi['longitude'] ?>">
            <input type="hidden" name="radius" value="<?= $lokasi_presensi['radius'] ?>">
            <input type="hidden" name="latitude_siswa" id="latitude_siswa">
            <input type="hidden" name="longitude_siswa" id="longitude_siswa">
            <input type="hidden" name="tanggal_masuk" value="<?= date('Y-m-d') ?>">
            <input type="hidden" name="jam_masuk" value="<?= date('H:i:s') ?>">
            <input type="hidden" name="id_siswa" id="id" value="<?= session()->get('id_siswa') ?>">

            <?php if ($current_time >= $start_time && $current_time <= $end_time) : ?>
              <button class="btn btn-primary mt-3">Masuk</button>
            <?php else : ?>
              <p class="text-danger mt-3">Absensi hanya bisa dilakukan antara jam 6 pagi hingga jam 6 sore.</p>
            <?php endif; ?>
          </form>
        </div>

      <?php else : ?>
        <div class="card-body">
          <h5 class="text-center">Anda telah melakukan absensi masuk</h5>
        </div>
      <?php endif; ?>
    </div>
  </div>


  <!-- absen keluar -->
  <div class="col-md-4">
    <div class="card h-100">
      <div class="card-header">Absensi Keluar</div>
      <?php if ($cek_presensi < 1) : ?>
        <div class="card-body">
          <h5 class="text-center">Anda belum melakukan absensi masuk</h5>
        </div>
      <?php elseif ($cek_presensi_keluar > 0) : ?>
        <div class="card-body">
          <h5 class="text-center">Anda telah melakukan absensi keluar</h5>
        </div>
      <?php else : ?>
        <div class="card-body text-center">
          <div class="fw-bold"><?= date('d F Y ') ?></div>
          <div class="parent-clock">
            <div id="jam-keluar"></div>
            <div>:</div>
            <div id="menit-keluar"></div>
            <div>:</div>
            <div id="detik-keluar"></div>
          </div>
          <form method="POST" action="<?= base_url('siswa/presensi_keluar/' . $ambil_presensi_masuk['id']) ?> " id="form1">
            <?php
            if ($lokasi_presensi['zona_waktu'] == 'WIB') {
              date_default_timezone_set('Asia/Jakarta');
            } elseif ($lokasi_presensi['zona_waktu'] == 'WITA') {
              date_default_timezone_set('Asia/Makassar');
            } elseif ($lokasi_presensi['zona_waktu'] == 'WIT') {
              date_default_timezone_set('Asia/Jayapura');
            }

            $current_time = date('H:i:s');
            $start_time_keluar = '15:00:00'; // 3 sore
            $end_time_keluar = '18:00:00';   // 6 sore
            ?>

            <input type="hidden" name="latitude_kantor" value="<?= $lokasi_presensi['latitude'] ?>">
            <input type="hidden" name="longitude_kantor" value="<?= $lokasi_presensi['longitude'] ?>">
            <input type="hidden" name="radius" value="<?= $lokasi_presensi['radius'] ?>">

            <input type="hidden" name="latitude_siswa" id="latitude_siswa">
            <input type="hidden" name="longitude_siswa" id="longitude_siswa">

            <input type="hidden" name="tanggal_keluar" value="<?= date('Y-m-d') ?>">
            <input type="hidden" name="jam_keluar" value="<?= date('H:i:s') ?>">

            <?php if ($current_time >= $start_time_keluar && $current_time <= $end_time_keluar) : ?>
              <button type="submit" id="submitBtn" class="btn btn-danger mt-3">Yes Pulang</button>
            <?php else : ?>
              <p class="text-danger mt-3">Absensi pulang hanya bisa dilakukan antara jam 3 sore hingga jam 6 sore.</p>
            <?php endif; ?>
          </form>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <div class="col-md-2"></div>
</div>

<div id="map"></div>


<script>
  window.setInterval("waktuMasuk()", 1000);

  function waktuMasuk() {
    const waktu = new Date();
    document.getElementById("jam-masuk").innerHTML = formatWaktu(waktu.getHours());
    document.getElementById("menit-masuk").innerHTML = formatWaktu(waktu.getMinutes());
    document.getElementById("detik-masuk").innerHTML = formatWaktu(waktu.getSeconds());
  }

  window.setInterval("waktuKeluar()", 1000);

  function waktuKeluar() {
    const waktu = new Date();
    document.getElementById("jam-keluar").innerHTML = formatWaktu(waktu.getHours());
    document.getElementById("menit-keluar").innerHTML = formatWaktu(waktu.getMinutes());
    document.getElementById("detik-keluar").innerHTML = formatWaktu(waktu.getSeconds());
  }



  function formatWaktu(waktu) {
    if (waktu < 10) {
      return "0" + waktu;
    } else {
      return waktu;
    }
  }


  getLocation();

  function getLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(showPosition);
    } else {
      alert("Browser Anda tidak mendukung Geolocation");
    }
  }

  function showPosition(position) {

    var latitude_siswa = position.coords.latitude;
    var longitude_siswa = position.coords.longitude;
    document.getElementById('latitude_siswa').value = latitude_siswa;
    document.getElementById('longitude_siswa').value = longitude_siswa;

    initMap(latitude_siswa, longitude_siswa)
  }

  function initMap(latitude_siswa, longitude_siswa) {
    var map = L.map('map').setView([<?= $lokasi_presensi['latitude'] ?>, <?= $lokasi_presensi['longitude'] ?>], 13);

    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(map);

    var marker = L.marker([<?= $lokasi_presensi['latitude'] ?>, <?= $lokasi_presensi['longitude'] ?>]).addTo(map);

    var circle = L.circle([latitude_siswa, longitude_siswa], {
      color: 'red',
      fillColor: '#f03',
      fillOpacity: 0.5,
      radius: 50
    }).addTo(map);

    var greenIcon = L.icon({
      iconUrl: '<?= base_url('assets/images/gedung-baru.png') ?>',
      shadowUrl: '<?= base_url('assets/images/gedung-baru.png') ?>',

      iconSize: [38, 95], // size of the icon
      shadowSize: [50, 64], // size of the shadow
      iconAnchor: [22, 94], // point of the icon which will correspond to marker's location
      shadowAnchor: [4, 62], // the same for the shadow
      popupAnchor: [-3, -76] // point from which the popup should open relative to the iconAnchor
    });

    L.marker([<?= $lokasi_presensi['latitude'] ?>, <?= $lokasi_presensi['longitude'] ?>], {
      icon: greenIcon
    }).addTo(map);

    circle.bindPopup("lokasi saat ini ");

  }

  // functuon button
  // const submitBtn = document.getElementById('submitBtn');
  // const form1 = document.getElementById('form1');
  // const form2 = document.getElementById('form2');

  // submitBtn.addEventListener('click', () => {
  // Simulasikan klik pada tombol submit tersembunyi
  //     form2.querySelector('input[type="submit"]').click();
  //     form1.querySelector('input[type="submit"]').click();
  // });
</script>
<?= $this->endSection() ?>