<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="shortcut icon" href="assets/images/favicon.svg" type="image/x-icon" />
  <title><?= $title ?></title>

  <!-- ========== All CSS files linkup ========= -->
  <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?> " />
  <link rel="stylesheet" href="<?= base_url('assets/css/lineicons.css') ?> " />
  <link rel="stylesheet" href="<?= base_url('assets/css/materialdesignicons.min.css') ?> " />
  <link rel="stylesheet" href="<?= base_url('assets/css/fullcalendar.css') ?> " />
  <link rel="stylesheet" href="<?= base_url('assets/css/main.css') ?> " />

  <!-- Datatables -->
  <link rel="stylesheet" href="https://cdn.datatables.net/2.1.2/css/dataTables.dataTables.css" />

  <!-- tabler icon -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tabler-icons/1.35.0/iconfont/tabler-icons.min.css" integrity="sha512-tpsEzNMLQS7w9imFSjbEOHdZav3/aObSESAL1y5jyJDoICFF2YwEdAHOPdOr1t+h8hTzar0flphxR76pd0V1zQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <!--  leafleat css -->
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
    integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
    crossorigin="" />

  <!-- leaflet js -->
  <!-- Make sure you put this AFTER Leaflet's CSS -->
  <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
    integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="
    crossorigin=""></script>


</head>

<body>
  <!-- ======== Preloader =========== -->
  <div id="preloader">
    <div class="spinner"></div>
  </div>
  <!-- ======== Preloader =========== -->

  <!-- ======== sidebar-nav start =========== -->
  <aside class="sidebar-nav-wrapper">
    <div class="navbar-logo">
      <a href="<?= base_url('siswa/home') ?>">
        <img width="80%" src="<?= base_url('assets/images/Logo/logo-new.png') ?>" alt="logo" />
      </a>
    </div>



    <nav class="sidebar-nav">
      <ul>
        <li class="nav-item mb-2">
          <a href="<?= base_url('siswa/home') ?>">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-home">
              <path stroke="none" d="M0 0h24v24H0z" fill="none" />
              <path d="M5 12l-2 0l9 -9l9 9l-2 0" />
              <path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7" />
              <path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6" />
            </svg>
            <span class="text">Dashboard</span>
          </a>
        </li>
        <li class="nav-item mb-2">
          <a href="<?= base_url('siswa/rekap_presensi/') ?>">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-report-analytics">
              <path stroke="none" d="M0 0h24v24H0z" fill="none" />
              <path d="M9 5h-2a2 2 0 0 0 -2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-12a2 2 0 0 0 -2 -2h-2" />
              <path d="M9 3m0 2a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v0a2 2 0 0 1 -2 2h-2a2 2 0 0 1 -2 -2z" />
              <path d="M9 17v-5" />
              <path d="M12 17v-1" />
              <path d="M15 17v-3" />
            </svg>
            <span class="text">Rekap Absensi</span>
          </a>
        </li>

        <li class="nav-item mb-2">
          <a href="<?= base_url('siswa/ketidakhadiran') ?>">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-user-x">
              <path stroke="none" d="M0 0h24v24H0z" fill="none" />
              <path d="M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0" />
              <path d="M6 21v-2a4 4 0 0 1 4 -4h3.5" />
              <path d="M22 22l-5 -5" />
              <path d="M17 22l5 -5" />
            </svg>
            <span class="text">Ketidakhadiran</span>
          </a>
        </li>

        <li class="nav-item mb-2">
          <a href="<?= base_url('siswa/faq') ?>">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-file-info">
              <path stroke="none" d="M0 0h24v24H0z" fill="none" />
              <path d="M14 3v4a1 1 0 0 0 1 1h4" />
              <path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z" />
              <path d="M11 14h1v4h1" />
              <path d="M12 11h.01" />
            </svg>
            <span class="text">FAQ</span>
          </a>
        </li>

        <li class="nav-item mb-2">
          <a href="<?= base_url('logout') ?>">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-logout">
              <path stroke="none" d="M0 0h24v24H0z" fill="none" />
              <path d="M14 8v-2a2 2 0 0 0 -2 -2h-7a2 2 0 0 0 -2 2v12a2 2 0 0 0 2 2h7a2 2 0 0 0 2 -2v-2" />
              <path d="M9 12h12l-3 -3" />
              <path d="M18 15l3 -3" />
            </svg>
            <span class="text">Log Out</span>
          </a>
        </li>
      </ul>
    </nav>
  </aside>
  <div class="overlay"></div>
  <!-- ======== sidebar-nav end =========== -->

  <!-- ======== main-wrapper start =========== -->
  <main class="main-wrapper">
    <!-- ========== header start ========== -->
    <header class="header">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-5 col-md-5 col-6">
            <div class="header-left d-flex align-items-center">
              <div class="menu-toggle-btn mr-15">
                <button id="menu-toggle" class="main-btn primary-btn btn-hover">
                  <i class="lni lni-chevron-left me-2"></i> Menu
                </button>
              </div>
            </div>
          </div>
          <div class="col-lg-7 col-md-7 col-6">
            <div class="header-right">
              <!-- profile start -->
              <div class="profile-box ml-15">
                <button class="dropdown-toggle bg-transparent border-0" type="button" id="profile"
                  data-bs-toggle="dropdown" aria-expanded="false">
                  <div class="profile-info">
                    <div class="info">
                      <div class="image">
                        <img style="width:45px; height: 45px; object-fit: cover;" src="<?= base_url('profile/' . session()->get('foto')) ?>" alt="" />
                      </div>
                      <div>
                        <h6 class="fw-500 text-uppercase"><?= session()->get('username') ?></h6>
                        <p><?= session()->get('role_id') ?></p>
                      </div>
                    </div>
                  </div>
                </button>
              </div>
              <!-- profile end -->
            </div>
          </div>
        </div>
      </div>
    </header>
    <!-- ========== header end ========== -->

    <!-- ========== section start ========== -->
    <section class="section">
      <div class="container-fluid">
        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-4 mb-4 mt-3"
          style="background: linear-gradient(135deg, #6d8ebb, #99cbd3 80%);
             border-radius: 10px;
             box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
             padding: 2px;">
          <div class="row align-items-center">
            <!-- Bagian kiri: Title -->
            <div class="col-md-6 col-sm-12">
              <div class="title d-flex align-items-center mt-2"
                style="text-transform: uppercase; font-size: 20px; font-weight: 600; color: #333;">
                <h3 class="m-0 p-0 "
                  style="transition: all 0.3s ease-in-out; margin-left: 20px; margin-top: 10px;">
                  <?= $title ?>
                </h3>
              </div>
            </div>

            <!-- Bagian kanan: Tanggal dan Jam -->
            <div class="col-md-6 col-sm-12 text-end text-center mt-3 mt-md-0">
              <div class="title-extra" style="font-size: 16px; color: #666;">
                <p class="m-0"> <?= date('d M Y') ?> | Jam: <span id="time"></span></p>
              </div>
            </div>
          </div>
        </div>
        <!-- ========== title-wrapper end ========== -->
        <?= $this->renderSection('Content') ?>
      </div>
      <!-- end container -->
    </section>
    <!-- ========== section end ========== -->


  </main>
  <!-- ======== main-wrapper end =========== -->

  <!-- ========= All Javascript files linkup ======== -->
  <script src=" <?= base_url('assets/js/bootstrap.bundle.min.js') ?> "></script>
  <script src=" <?= base_url('assets/js/jvectormap.min.js') ?> "></script>
  <script src=" <?= base_url('assets/js/polyfill.js') ?> "></script>
  <script src=" <?= base_url('assets/js/main.js') ?> "></script>

  <!-- jqury -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

  <!--datatables -->
  <script src="https://cdn.datatables.net/2.1.2/js/dataTables.js"></script>


  <!-- sweetalert -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <script>
    // data tables
    $(document).ready(function() {
      $.fn.dataTable.ext.errMode = 'none';
      $('#datatables').DataTable();
    });


    // swich alert 
    $(function() {
      <?php if (session()->has('gagal')) { ?>
        Swal.fire({
          icon: "error",
          title: "Oops...",
          text: "<?= session()->get('gagal') ?>",
        });
      <?php } ?>
    });



    //  swict alert kofirm

    $('.tombol-hapus').on('click', function() {
      var getLink = $(this).attr('href');
      Swal.fire({
        title: "Yakin dek?",
        text: "Data yang sudah di hapus tidak dapat di kembalikan",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Iya Dong"
      }).then((result) => {
        if (result.isConfirmed) {
          window.location.href = getLink
        }
      });

      return false;

    });


    // swich alert
    $(function() {
      <?php if (session()->has('berhasil')) { ?>
        const Toast = Swal.mixin({
          toast: true,
          position: "top-end",
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.onmouseenter = Swal.stopTimer;
            toast.onmouseleave = Swal.resumeTimer;
          }
        });
        Toast.fire({
          icon: "success",
          title: "<?= $_SESSION['berhasil'] ?>"
        });
      <?php } ?>
    });

    function updateTime() {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      const seconds = String(now.getSeconds()).padStart(2, '0');

      const timeString = hours + ':' + minutes + ':' + seconds;
      document.getElementById('time').textContent = timeString;
    }

    // Update the time every second
    setInterval(updateTime, 1000);

    // Initialize time immediately when the page loads
    updateTime();
  </script>

</body>

</html>