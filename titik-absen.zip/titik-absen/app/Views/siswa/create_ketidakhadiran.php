<?= $this->extend('siswa/layout.php') ?>

<?= $this->section('Content') ?>
    <div class="card col-md-6">
        <div class="card-body ">
        <form action="<?=  base_url('siswa/ketidakhadiran/store')?>" method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" value="<?= session()->get('id_siswa')?>" name="id_siswa">

            <div class="input-style-1">
                <label>Keterangan</label>
                <select name="keterangan" class="<?= ($validation->hasError('keterangan')) ? 'is-invalid' : ''  ?> form-control" >
                    <option value="">---Pilih Jenis Keterangan---</option>
                    <option value="Izin">Izin</option>
                    <option value="Sakit">Sakit</option>
                </select>
                <div class="invalid-feedback"><?= $validation->getError('keterangan')?></div>
            </div>


            <div class="input-style-1"> 
                <label>Tanggal Ketidakhadiran</label>
                <input type="date" name="tanggal" value="<?= set_value('tanggal')?>" class="<?= ($validation->hasError('tanggal')) ? 'is-invalid' : ''  ?> form-control" />
                <div class="invalid-feedback"><?= $validation->getError('tanggal')?></div>
            </div>

            <div class="input-style-1">
                <label>Deskripsi</label>
                <textarea name="deskripsi" placeholder="deskripsi" class="<?= ($validation->hasError('deskripsi')) ? 'is-invalid' : ''  ?> form-control" cols="30" rows="5" ></textarea>
                <div class="invalid-feedback"><?= $validation->getError('deskripsi')?></div>
            </div>

            <div class="input-style-1">
                <label>File</label>
                <input type="file" name="file" class="<?= ($validation->hasError('file')) ? 'is-invalid' : ''  ?> form-control" />
                <div class="invalid-feedback"><?= $validation->getError('file')?></div>
            </div>
            <div class="input-style-1">
                <button type="submit" class="btn btn-primary">Ajukan</button>
            </div>
            
    </div>
<?= $this->endSection() ?>