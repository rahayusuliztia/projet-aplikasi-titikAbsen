<?= $this->extend('siswa/layout.php') ?>

<?= $this->section('Content') ?>
<!-- webcam -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.26/webcam.min.js" integrity="sha512-dQIiHSl2hr3NWKKLycPndtpbh5iaHLo6MwrXm7F0FM5e+kL2U16oE9uIwPHUl6fQBeCthiEuV/rzP3MiAB8Vfw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<input type="hidden" id="id_siswa" name="id_siswa" value="<?= $id_siswa ?>">
<input type="hidden" id="tanggal_masuk" name="tanggal_masuk" value="<?= $tanggal_masuk ?>">
<input type="hidden" id="jam_masuk" name="jam_masuk" value="<?= $jam_masuk ?>">

<!-- Styling -->
<style>
    .camera-container {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        margin-top: 20px;
    }

    .card {
        border-radius: 15px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        max-width: 400px;
        width: 100%;
        margin: auto;
        padding: 20px;
        background-color: #fff;
    }

    #my_camera {
        width: 100%;
        max-width: 100%;
        /* Sesuaikan dengan card */
        height: auto;
        border: 2px solid #ccc;
        border-radius: 10px;
        padding: 10px;
        background-color: #f9f9f9;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        margin-bottom: 10px;
        object-fit: contain;
        /* Untuk menjaga gambar tetap dalam batas elemen */
    }

    #ambil_foto {
        width: 100%;
        background: linear-gradient(135deg, #6e8efb, #a777e3);
        border: none;
        padding: 10px;
        color: white;
        font-weight: bold;
        border-radius: 10px;
        transition: 0.3s;
    }

    #ambil_foto:hover {
        background: linear-gradient(135deg, #a777e3, #6e8efb);
        cursor: pointer;
    }

    /* Responsive styling */
    @media (max-width: 768px) {
        .card {
            max-width: 100%;
        }
    }
</style>

<!-- Kamera di dalam Card -->
<div class="camera-container">
    <div class="card">
        <h4 class="text-center mb-4">Ambil Foto Absensi</h4>
        <div id="my_camera"></div>
        <button class="btn btn-primary mt-2" id="ambil_foto">Masuk</button>
        <div id="my_result" style="display: none;"></div>
    </div>
</div>

<script>
    function adjustCameraSize() {
        let screenWidth = window.innerWidth;

        // Atur ukuran webcam berdasarkan ukuran layar
        let width = screenWidth > 768 ? 320 : 240;
        let height = screenWidth > 768 ? 240 : 180;

        Webcam.set({
            width: width,
            height: height,
            dest_width: width,
            dest_height: height,
            image_format: 'jpeg',
            jpeg_quality: 90,
            force_flash: false
        });
        Webcam.attach('#my_camera');
    }

    // Panggil fungsi untuk mengatur ukuran saat halaman dimuat
    adjustCameraSize();

    // Panggil fungsi saat ukuran jendela berubah (untuk responsivitas)
    window.addEventListener('resize', adjustCameraSize);

    document.getElementById('ambil_foto').addEventListener('click', function() {
        let id = document.getElementById('id_siswa').value;
        let tanggal_masuk = document.getElementById('tanggal_masuk').value;
        let jam_masuk = document.getElementById('jam_masuk').value;

        Webcam.snap(function(data_uri) {
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                document.getElementById('my_result').innerHTML = '<img src="' + data_uri + '"/>';
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    window.location.href = '<?= base_url('siswa/home') ?>';
                }
            };
            xhttp.open("POST", "<?= base_url('siswa/presensi_masuk_aksi') ?>", true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhttp.send(
                'foto_masuk=' + encodeURIComponent(data_uri) +
                '&id_siswa=' + id +
                '&tanggal_masuk=' + tanggal_masuk +
                '&jam_masuk=' + jam_masuk
            );
        })
    });
</script>

<?= $this->endSection() ?>