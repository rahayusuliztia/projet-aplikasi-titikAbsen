<?= $this->extend('siswa/layout.php') ?>

<?= $this->section('Content') ?>

<div class="mb-4">
    <form class="row g-3">
        <div class="col-md-4 col-sm-6 col-12">
            <input type="date" class="form-control" name="filter_tanggal" id="dateinput" required>
        </div>
        <div class="col-md-3 col-sm-6 col-12">
            <button type="submit" class="btn btn-primary mb-3 w-80">Tampilkan</button>
        </div>
    </form>
</div>

<div class="table-responsive mt-3">
    <table class="table table-striped" id="datatables">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Siswa</th>
                <th>Gender</th>
                <th>Tanggal</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($rekap_presensi): ?>
                <?php $no = 1; ?>
                <?php foreach ($rekap_presensi as $rekap): ?>
                    <?php

                    $jenis_kelamin = $Siswa['jenis_kelamin'] ?? '';
                    $foto_profil = $Siswa['foto_siswa'] ?? '';

                    // Menghitung keterlambatan
                    $jam_masuk_real = strtotime($rekap['jam_masuk']);
                    $jam_masuk_kantor = strtotime($rekap['jam_masuk_kantor']);
                    $selisih_terlambat = max(0, $jam_masuk_real - $jam_masuk_kantor);
                    $jam_terlambat = floor($selisih_terlambat / 3600);
                    $menit_terlambat = floor(($selisih_terlambat % 3600) / 60);
                    ?>

                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($rekap['nama']) ?></td>
                        <td><?= htmlspecialchars($jenis_kelamin) ?></td>
                        <td><?= date('d F Y', strtotime($rekap['tanggal_masuk'])) ?></td>
                        <td class="<?= $rekap['paraf'] === 'alfa' ? 'text-danger' : ($rekap['paraf'] === 'pandding' ? 'text-warning' : 'text-success') ?>">
                            <?= htmlspecialchars($rekap['paraf']) ?>
                        </td>
                        <td>
                            <a href="<?= base_url('siswa/detail_presensi/' . $rekap['id']) ?>" class="badge bg-info">Detail</a>
                        </td>

                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="text-center">Data tidak tersedia</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>


<?= $this->endSection() ?>