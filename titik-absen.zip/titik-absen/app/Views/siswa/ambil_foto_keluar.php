<?= $this->extend('siswa/layout.php') ?>

<?= $this->section('Content') ?>
<!-- webcam -->
<style>
    #kegiatan {
        width: 100%;
    }

    .card-webcam {
        max-width: 700px;
        /* Perbesar ukuran card untuk laptop */
        margin: auto;
        border-radius: 15px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .card-webcam .card-header {
        font-weight: bold;
        background-color: #f8f9fa;
        text-align: center;
        padding: 10px;
        border-bottom: 1px solid #ddd;
    }

    .card-webcam .card-body {
        text-align: center;
    }

    #my_camera {
        margin: 10px auto;
        border-radius: 10px;
        overflow: hidden;
        width: 100%;
        /* Full width for responsiveness */
    }

    /* Media query untuk layar besar (desktop atau laptop) */
    @media (min-width: 1024px) {
        #my_camera {
            width: 400px;
            /* Perbesar webcam pada layar laptop/desktop */
            height: auto;
        }
    }

    /* Media query untuk layar tablet atau lebih kecil */
    @media (max-width: 768px) {
        #my_camera {
            width: 100%;
            height: auto;
            /* Adjust height automatically */
        }
    }

    #ambil-foto-keluar {
        width: 100%;
        margin-top: 20px;
    }
</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.26/webcam.min.js" integrity="sha512-dQIiHSl2hr3NWKKLycPndtpbh5iaHLo6MwrXm7F0FM5e+kL2U16oE9uIwPHUl6fQBeCthiEuV/rzP3MiAB8Vfw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<div class="card card-webcam">
    <div class="card-header">
        Presensi Keluar
    </div>
    <div class="card-body">
        <input type="hidden" id="tanggal_keluar" name="tanggal_keluar" value="<?= $tanggal_keluar ?>">
        <input type="hidden" id="jam_keluar" name="jam_keluar" value="<?= $jam_keluar ?>">

        <label for="kegiatan" class="">Silakan isi kegiatan hari ini</label>
        <textarea rows="4" type="text" id="kegiatan" class="form-control mb-3" required></textarea>

        <div id="my_camera"></div>
        <div style="display: none;" id="my_result"></div>
        <button class="btn btn-danger mt-2" id="ambil-foto-keluar">Keluar</button>
    </div>
</div>

<script>
    Webcam.set({
        width: 320,
        height: 240,
        dest_width: 320,
        dest_height: 240,
        image_format: 'jpeg',
        jpeg_quality: 90,
        force_flash: false
    });

    function attachWebcam() {
        if (window.innerWidth <= 768) {
            // Adjust for smaller screens
            Webcam.set({
                width: 240,
                height: 180,
                dest_width: 240,
                dest_height: 180
            });
        } else if (window.innerWidth >= 1024) {
            // Adjust for larger screens
            Webcam.set({
                width: 400,
                height: 300,
                dest_width: 400,
                dest_height: 300
            });
        }
        Webcam.attach('#my_camera');
    }

    // Attach webcam on load
    attachWebcam();

    document.getElementById('ambil-foto-keluar').addEventListener('click',
        function() {
            let tanggal_keluar = document.getElementById('tanggal_keluar').value;
            let jam_keluar = document.getElementById('jam_keluar').value;
            let kegiatan = document.getElementById('kegiatan').value;

            Webcam.snap(function(data_uri) {
                var xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function() {
                    document.getElementById('my_result').innerHTML = '<img src="' + data_uri + '"/>';
                    if (xhttp.readyState == 4 && xhttp.status == 200) {
                        window.location.href = '<?= base_url('siswa/home') ?>';
                    }
                };

                xhttp.open("POST", "<?= base_url('siswa/presensi_keluar_aksi/' . $id_presensi) ?>", true);
                xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xhttp.send(
                    'foto_keluar=' + encodeURIComponent(data_uri) +
                    '&tanggal_keluar=' + tanggal_keluar +
                    '&jam_keluar=' + jam_keluar +
                    '&kegiatan=' + kegiatan
                );
            });
        }
    );
</script>

<?= $this->endSection() ?>