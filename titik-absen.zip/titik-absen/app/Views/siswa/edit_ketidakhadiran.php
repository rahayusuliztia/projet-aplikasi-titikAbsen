<?= $this->extend('siswa/layout.php') ?>

<?= $this->section('Content') ?>
    <div class="card col-md-6">
        <div class="card-body ">
        <form action="<?=  base_url('siswa/ketidakhadiran/update/'.$ketidakhadiran['id'])?>" method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>

            <div class="input-style-1">
                <label>Keterangan</label>
                <select name="keterangan" class="<?= ($validation->hasError('keterangan')) ? 'is-invalid' : ''  ?> form-control" >
                    <option value=""><?= $ketidakhadiran['keterangan']?></option>
                    <option value="Izin">Izin</option>
                    <option value="Sakit">Sakit</option>
                </select>
                <div class="invalid-feedback"><?= $validation->getError('keterangan')?></div>
            </div>


            <div class="input-style-1"> 
                <label>Tanggal Ketidakhadiran</label>
                <input type="date" name="tanggal" value="<?= $ketidakhadiran['tanggal']?>" class="<?= ($validation->hasError('tanggal')) ? 'is-invalid' : ''  ?> form-control" />
                <div class="invalid-feedback"><?= $validation->getError('tanggal')?></div>
            </div>

            <div class="input-style-1">
                <label>Deskripsi</label>
                <textarea name="deskripsi" placeholder="deskripsi" class="<?= ($validation->hasError('deskripsi')) ? 'is-invalid' : ''  ?> form-control" cols="30" rows="5" ><?= $ketidakhadiran['deskripsi']?></textarea>
                <div class="invalid-feedback"><?= $validation->getError('deskripsi')?></div>
            </div>

            <div class="input-style-1">
                <label>File</label>
                <input type="hidden" name="file_lama" value="<?= $ketidakhadiran['file']?>">
                <input type="file" name="file" class="<?= ($validation->hasError('file')) ? 'is-invalid' : ''  ?> form-control" />
                <div class="invalid-feedback"><?= $validation->getError('file')?></div>
            </div>
            <div class="input-style-1">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
            
    </div>
<?= $this->endSection() ?>