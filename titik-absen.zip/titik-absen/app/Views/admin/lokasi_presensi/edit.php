<?= $this->extend('admin/layout.php') ?>

<?= $this->section('Content') ?>
<div class="container-fluid">
    <div class="row">
        <!-- Bagian Kiri -->
        <div class="col-md-6 p-5 bg-white text-dark">
            <h3 class="mb-4">Informasi Lokasi Presensi</h3>
            <form action="<?= base_url('admin/lokasi_presensi/update/' . $lokasi_presensi['id']) ?>" method="post">
                <?= csrf_field() ?>
                <div class="input-style-1 mb-3">
                    <label>Nama Lokasi</label>
                    <input type="text" value="<?= $lokasi_presensi['nama_lokasi'] ?>" name="nama_lokasi" placeholder="Nama lokasi" class="<?= ($validation->hasError('nama_lokasi')) ? 'is-invalid' : '' ?> form-control" />
                    <div class="invalid-feedback"><?= $validation->getError('nama_lokasi') ?></div>
                </div>
                <div class="input-style-1 mb-3">
                    <label>Alamat Lokasi</label>
                    <textarea name="alamat_lokasi" placeholder="Alamat lokasi" class="<?= ($validation->hasError('alamat_lokasi')) ? 'is-invalid' : '' ?> form-control" rows="3"><?= $lokasi_presensi['alamat_lokasi'] ?></textarea>
                    <div class="invalid-feedback"><?= $validation->getError('alamat_lokasi') ?></div>
                </div>
                <div class="input-style-1 mb-3">
                    <label>Tipe Lokasi</label>
                    <input type="text" value="<?= $lokasi_presensi['tipe_lokasi'] ?>" name="tipe_lokasi" placeholder="Tipe lokasi" class="<?= ($validation->hasError('tipe_lokasi')) ? 'is-invalid' : '' ?> form-control" />
                    <div class="invalid-feedback"><?= $validation->getError('tipe_lokasi') ?></div>
                </div>
                <div class="input-style-1 mb-3">
                    <label>Latitude</label>
                    <input type="text" value="<?= $lokasi_presensi['latitude'] ?>" name="latitude" placeholder="Latitude" class="<?= ($validation->hasError('latitude')) ? 'is-invalid' : '' ?> form-control" />
                    <div class="invalid-feedback"><?= $validation->getError('latitude') ?></div>
                </div>
            </form>
        </div>

        <!-- Bagian Kanan -->
        <div class="col-md-6 p-5" style="background-color: #ced4da; color: white;">
            <h3 class="mb-4">Detail Tambahan Lokasi</h3>
            <form action="<?= base_url('admin/lokasi_presensi/update/' . $lokasi_presensi['id']) ?>" method="post">
                <div class="input-style-1 mb-3">
                    <label>Longitude</label>
                    <input type="text" value="<?= $lokasi_presensi['longitude'] ?>" name="longitude" placeholder="Longitude" class="<?= ($validation->hasError('longitude')) ? 'is-invalid' : '' ?> form-control" />
                    <div class="invalid-feedback"><?= $validation->getError('longitude') ?></div>
                </div>

                <div class="input-style-1 mb-3">
                    <label>Radius</label>
                    <input type="number" value="<?= $lokasi_presensi['radius'] ?>" name="radius" placeholder="Radius" class="<?= ($validation->hasError('radius')) ? 'is-invalid' : '' ?> form-control" />
                    <div class="invalid-feedback"><?= $validation->getError('radius') ?></div>
                </div>

                <div class="input-style-1 mb-3">
                    <label>Zona Waktu</label>
                    <select name="zona_waktu" class="<?= ($validation->hasError('zona_waktu')) ? 'is-invalid' : '' ?> form-control">
                        <option value="">---Pilih---</option>
                        <option value="WIB" <?= ($lokasi_presensi['zona_waktu'] == 'WIB') ? 'selected' : '' ?>>WIB</option>
                        <option value="WITA" <?= ($lokasi_presensi['zona_waktu'] == 'WITA') ? 'selected' : '' ?>>WITA</option>
                        <option value="WIT" <?= ($lokasi_presensi['zona_waktu'] == 'WIT') ? 'selected' : '' ?>>WIT</option>
                    </select>
                    <div class="invalid-feedback"><?= $validation->getError('zona_waktu') ?></div>
                </div>

                <div class="input-style-1 mb-3">
                    <label>Jam Masuk</label>
                    <input type="time" value="<?= $lokasi_presensi['jam_masuk'] ?>" name="jam_masuk" class="<?= ($validation->hasError('jam_masuk')) ? 'is-invalid' : '' ?> form-control" />
                    <div class="invalid-feedback"><?= $validation->getError('jam_masuk') ?></div>
                </div>

                <div class="input-style-1 mb-3">
                    <label>Jam Pulang</label>
                    <input type="time" value="<?= $lokasi_presensi['jam_pulang'] ?>" name="jam_pulang" class="<?= ($validation->hasError('jam_pulang')) ? 'is-invalid' : '' ?> form-control" />
                    <div class="invalid-feedback"><?= $validation->getError('jam_pulang') ?></div>
                </div>

                <button type="submit" class="btn btn-secondary btn-lg">Update</button>
            </form>
        </div>
    </div>
</div>
<?= $this->endSection() ?>