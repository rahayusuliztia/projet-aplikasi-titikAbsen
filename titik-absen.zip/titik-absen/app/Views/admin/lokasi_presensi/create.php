<?= $this->extend('admin/layout.php') ?>

<?= $this->section('Content') ?>
<div class="container-fluid">
    <div class="row">
        <!-- Bagian Kiri -->
        <div class="col-md-6 p-5 bg-white text-dark">
            <h3 class="mb-4">Informasi Lokasi Presensi</h3>
            <form action="<?= base_url('admin/lokasi_presensi/store') ?>" method="post">
                <?= csrf_field() ?>
                <div class="input-style-1 mb-3">
                    <label>Nama Lokasi</label>
                    <input type="text" name="nama_lokasi" placeholder="Nama lokasi" class="<?= ($validation->hasError('nama_lokasi')) ? 'is-invalid' : '' ?> form-control" />
                    <div class="invalid-feedback"><?= $validation->getError('nama_lokasi') ?></div>
                </div>
                <div class="input-style-1 mb-3">
                    <label>Alamat Lokasi</label>
                    <textarea name="alamat_lokasi" placeholder="Alamat lokasi" class="<?= ($validation->hasError('alamat_lokasi')) ? 'is-invalid' : '' ?> form-control" rows="3"></textarea>
                    <div class="invalid-feedback"><?= $validation->getError('alamat_lokasi') ?></div>
                </div>
                <div class="input-style-1 mb-3">
                    <label>Tipe Lokasi</label>
                    <input type="text" name="tipe_lokasi" placeholder="Tipe lokasi" class="<?= ($validation->hasError('tipe_lokasi')) ? 'is-invalid' : '' ?> form-control" />
                    <div class="invalid-feedback"><?= $validation->getError('tipe_lokasi') ?></div>
                </div>
                <div class="input-style-1 mb-3">
                    <label>Latitude</label>
                    <input type="text" name="latitude" placeholder="Latitude" class="<?= ($validation->hasError('latitude')) ? 'is-invalid' : '' ?> form-control" />
                    <div class="invalid-feedback"><?= $validation->getError('latitude') ?></div>
                </div>
            </form>
        </div>

        <!-- Bagian Kanan -->
        <div class="col-md-6 p-5" style="background-color: #ced4da; color: white;">
            <h3 class="mb-4">Detail Tambahan Lokasi</h3>
            <form action="<?= base_url('admin/lokasi_presensi/store') ?>" method="post">
                <div class="input-style-1 mb-3">
                    <label>Longitude</label>
                    <input type="text" name="longitude" placeholder="Longitude" class="<?= ($validation->hasError('longitude')) ? 'is-invalid' : '' ?> form-control" />
                    <div class="invalid-feedback"><?= $validation->getError('longitude') ?></div>
                </div>

                <div class="input-style-1 mb-3">
                    <label>Radius</label>
                    <input type="number" name="radius" placeholder="Radius" class="<?= ($validation->hasError('radius')) ? 'is-invalid' : '' ?> form-control" />
                    <div class="invalid-feedback"><?= $validation->getError('radius') ?></div>
                </div>

                <div class="input-style-1 mb-3">
                    <label>Zona Waktu</label>
                    <select name="zona_waktu" class="<?= ($validation->hasError('zona_waktu')) ? 'is-invalid' : '' ?> form-control">
                        <option value="">--- Pilih ---</option>
                        <option value="WIB">WIB</option>
                        <option value="WITA">WITA</option>
                        <option value="WIT">WIT</option>
                    </select>
                    <div class="invalid-feedback"><?= $validation->getError('zona_waktu') ?></div>
                </div>

                <div class="input-style-1 mb-3">
                    <label>Jam Masuk</label>
                    <input type="time" name="jam_masuk" class="<?= ($validation->hasError('jam_masuk')) ? 'is-invalid' : '' ?> form-control" />
                    <div class="invalid-feedback"><?= $validation->getError('jam_masuk') ?></div>
                </div>

                <div class="input-style-1 mb-3">
                    <label>Jam Pulang</label>
                    <input type="time" name="jam_pulang" class="<?= ($validation->hasError('jam_pulang')) ? 'is-invalid' : '' ?> form-control" />
                    <div class="invalid-feedback"><?= $validation->getError('jam_pulang') ?></div>
                </div>

                <button type="submit" class="btn btn-secondary btn-lg">Simpan</button>
            </form>
        </div>
    </div>
</div>
<?= $this->endSection() ?>