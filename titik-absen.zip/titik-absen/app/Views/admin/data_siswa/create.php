<?= $this->extend('admin/layout.php') ?>

<?= $this->section('Content') ?>
<div class="card">
    <div class="card-body">
        <form action="<?= base_url('admin/data_siswa/store') ?>" method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <div class="row">
                <!-- Left Column -->
                <div class="col-md-6">
                    <div class="input-style-1">
                        <label>Nama</label>
                        <input type="text" name="nama" placeholder="Nama" class="<?= ($validation->hasError('nama')) ? 'is-invalid' : ''  ?> form-control" />
                        <div class="invalid-feedback"><?= $validation->getError('nama') ?></div>
                    </div>

                    <div class="input-style-1">
                        <label>NISN</label>
                        <input type="text" name="nisn" placeholder="NISN" class="<?= ($validation->hasError('nisn')) ? 'is-invalid' : ''  ?> form-control" />
                        <div class="invalid-feedback"><?= $validation->getError('nisn') ?></div>
                    </div>

                    <div class="input-style-1">
                        <label>Jenis Kelamin</label>
                        <select name="jenis_kelamin" class="<?= ($validation->hasError('jenis_kelamin')) ? 'is-invalid' : ''  ?> form-control">
                            <option value="">---Pilih Jenis Kelamin---</option>
                            <option value="Laki-laki">Laki-laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </select>
                        <div class="invalid-feedback"><?= $validation->getError('jenis_kelamin') ?></div>
                    </div>

                    <div class="input-style-1">
                        <label>Alamat</label>
                        <textarea name="alamat" placeholder="Alamat" class="<?= ($validation->hasError('alamat')) ? 'is-invalid' : ''  ?> form-control" cols="30" rows="5"></textarea>
                        <div class="invalid-feedback"><?= $validation->getError('alamat') ?></div>
                    </div>

                    <div class="input-style-1">
                        <label>No HP</label>
                        <input type="text" name="no_hanphone" placeholder="Nomor HP" class="<?= ($validation->hasError('no_hanphone')) ? 'is-invalid' : ''  ?> form-control" />
                        <div class="invalid-feedback"><?= $validation->getError('no_hanphone') ?></div>
                    </div>
                    <div class="input-style-1">
                        <label>Jabatan</label>
                        <select name="jabatan" class="<?= ($validation->hasError('jabatan')) ? 'is-invalid' : ''  ?> form-control">
                            <option value="">---Pilih Jabatan---</option>
                            <?php foreach ($jabatan as $jab) : ?>
                                <option value="<?= $jab['jabatan'] ?>"><?= $jab['jabatan'] ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback"><?= $validation->getError('jabatan') ?></div>
                    </div>
                </div>

                <!-- Right Column -->
                <div class="col-md-6" style="background-color: #ced4da; padding: 15px; color: white;">
                    <div class="input-style-1">
                        <label>Lokasi Presensi</label>
                        <select name="lokasi_presensi" class="<?= ($validation->hasError('lokasi_presensi')) ? 'is-invalid' : ''  ?> form-control">
                            <option value="">---Pilih Lokasi Presensi---</option>
                            <?php foreach ($lokasi_presensi as $lok) : ?>
                                <option value="<?= $lok['id'] ?>"><?= $lok['nama_lokasi'] ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback"><?= $validation->getError('lokasi_presensi') ?></div>
                    </div>

                    <div class="input-style-1">
                        <label>Foto</label>
                        <input type="file" name="foto_siswa" class="<?= ($validation->hasError('foto_siswa')) ? 'is-invalid' : ''  ?> form-control" required />
                        <div class="invalid-feedback"><?= $validation->getError('foto_siswa') ?></div>
                    </div>

                    <div class="input-style-1">
                        <label>Username</label>
                        <input type="text" name="username" placeholder="Username" class="<?= ($validation->hasError('username')) ? 'is-invalid' : ''  ?> form-control" />
                        <div class="invalid-feedback"><?= $validation->getError('username') ?></div>
                    </div>

                    <div class="input-style-1">
                        <label>Password</label>
                        <input type="password" name="password" placeholder="Password" class="<?= ($validation->hasError('password')) ? 'is-invalid' : ''  ?> form-control" />
                        <div class="invalid-feedback"><?= $validation->getError('password') ?></div>
                    </div>

                    <div class="input-style-1">
                        <label>Konfirmasi Password</label>
                        <input type="password" name="konfirmasi_password" placeholder="Konfirmasi Password" class="<?= ($validation->hasError('konfirmasi_password')) ? 'is-invalid' : ''  ?> form-control" />
                        <div class="invalid-feedback"><?= $validation->getError('konfirmasi_password') ?></div>
                    </div>

                    <div class="input-style-1">
                        <label>Role</label>
                        <select name="role" class="<?= ($validation->hasError('role')) ? 'is-invalid' : ''  ?> form-control">
                            <option value="">---Pilih Role---</option>
                            <option value="admin">Admin</option>
                            <option value="siswa">Siswa</option>
                        </select>
                        <div class="invalid-feedback"><?= $validation->getError('role') ?></div>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-secondary mt-2">Simpan</button>
        </form>
    </div>
</div>
<?= $this->endSection() ?>