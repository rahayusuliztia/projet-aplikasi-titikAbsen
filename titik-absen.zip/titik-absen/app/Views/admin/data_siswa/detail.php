<?= $this->extend('admin/layout.php') ?>

<?= $this->section('Content') ?>

<div class="card col-md-8 mx-auto mt-4">
    <div class="card-body">
        <div class="d-flex align-items-center mb-4">
            <div style="width: 100px; height: 100px; overflow: hidden; border-radius: 50%; border: 2px solid #007bff; position: relative;">
                <img
                    class="w-100 h-100"
                    src="<?= base_url('profile/' . $siswa['foto_siswa']) ?>"
                    alt="Profile Picture"
                    style="object-fit: cover; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);"
                    data-bs-toggle="modal"
                    data-bs-target="#profileModal">
            </div>

            <div class="ms-3">
                <h5 class="mb-0"><?= $siswa['nama'] ?></h5>
                <p class="text-muted mb-0"><?= $siswa['jenis_kelamin'] ?></p>
            </div>
        </div>

        <table class="table">
            <thead class="thead-light">
                <tr>
                    <th scope="col">Detail</th>
                    <th scope="col">Information</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>NISN</td>
                    <td><?= $siswa['nisn'] ?></td>
                </tr>
                <tr>
                    <td>Username</td>
                    <td><?= $siswa['username'] ?></td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td><?= nl2br($siswa['alamat']) ?></td>
                </tr>
                <tr>
                    <td>No. Handphone</td>
                    <td><?= $siswa['no_hanphone'] ?></td>
                </tr>
                <tr>
                    <td>Jabatan</td>
                    <td><?= $siswa['jabatan'] ?></td>
                </tr>
                <tr>
                    <td>Lokasi Presensi</td>
                    <td><?= $siswa['lokasi_presensi'] ?></td>
                </tr>
                <tr>
                    <td>Status</td>
                    <td><?= $siswa['status'] ?></td>
                </tr>
                <tr>
                    <td>Role</td>
                    <td><?= $siswa['role'] ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal for displaying full image -->
<div class="modal fade" id="profileModal" tabindex="-1" aria-labelledby="profileModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="profileModalLabel">Profile Picture</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <img
                    src="<?= base_url('profile/' . $siswa['foto_siswa']) ?>"
                    alt="Profile Picture"
                    class="img-fluid"
                    style="max-width: 90%; height: auto; max-height: 400px;">
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>