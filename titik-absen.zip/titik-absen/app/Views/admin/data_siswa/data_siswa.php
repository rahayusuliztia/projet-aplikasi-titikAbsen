<?= $this->extend('admin/layout.php') ?>

<?= $this->section('Content') ?>

<div class="container-fluid mb-3">
    <a href="<?= base_url('admin/data_siswa/create') ?>" class="btn btn-primary d-inline-flex align-items-center">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-circle-plus mr-2">
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <path d="M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0" />
            <path d="M9 12h6" />
            <path d="M12 9v6" />
        </svg>
        Tambah Data
    </a>
</div>

<!-- Tabel responsif -->
<div class="table-responsive">
    <table class="table table-striped" id="datatables">
        <thead>
            <tr>
                <th>No</th>
                <th>NISN</th>
                <th>Nama</th>
                <th>Jabatan</th>
                <th>Lokasi Presensi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; ?>
            <?php foreach ($Siswa as $sis): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= htmlspecialchars($sis['nisn']) ?></td>
                    <td><?= htmlspecialchars($sis['nama']) ?></td>
                    <td><?= htmlspecialchars($sis['jabatan']) ?></td>
                    <td><?= htmlspecialchars($sis['lokasi_presensi']) ?></td>
                    <td>
                        <a href="<?= base_url('admin/data_siswa/detail/' . $sis['id']) ?>" class="badge bg-info">Detail</a>
                        <a href="<?= base_url('admin/data_siswa/edit/' . $sis['id']) ?>" class="badge bg-warning text-dark">Edit</a>
                        <a href="<?= base_url('admin/data_siswa/delete/' . $sis['id']) ?>" class="badge bg-danger tombol-hapus">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Penyesuaian tampilan untuk tombol aksi pada layar kecil -->
<style>
    @media (max-width: 576px) {
        td {
            white-space: nowrap;
            /* Menghindari text wrapping di kolom */
        }

        .badge {
            font-size: 0.8rem;
            padding: 0.3rem 0.5rem;
        }

        .icon {
            width: 18px;
            height: 18px;
        }
    }
</style>

<?= $this->endSection() ?>