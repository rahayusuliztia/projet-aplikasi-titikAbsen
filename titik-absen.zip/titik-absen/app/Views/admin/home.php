<?= $this->extend('admin/layout.php') ?>

<?= $this->section('Content') ?>


<div class="title-extra mb-3" style="font-size: 16px; color: #666;">
  <span style="font-size: 1.2rem; font-weight: 300;">Data Tanggal <?= date('d F Y') ?></span>
</div>
<?php date_default_timezone_set('Asia/Jakarta'); ?>

<div class="container-fluid">
  <div class="row">
    <!-- Total Siswa -->
    <div class="col-xl-3 col-lg-4 col-sm-6 col-12 mb-4">
      <div class="icon-card card-shadow bg-white rounded-lg p-3 text-center hover-transform">
        <div class="icon purple mb-3">
          <i class="lni lni-users" style="font-size: 2.5rem; color: #4b5563;"></i>
        </div>
        <div class="content">
          <h6 class="text-muted">Total Siswa</h6>
          <h3 class="text-bold"><?= $total_siswa - 1; ?></h3>
        </div>
      </div>
    </div>

    <!-- Hadir -->
    <div class="col-xl-3 col-lg-4 col-sm-6 col-12 mb-4">
      <div class="icon-card card-shadow bg-white rounded-lg p-3 text-center hover-transform">
        <div class="icon success mb-3">
          <i class="lni lni-checkmark-circle" style="font-size: 2.5rem; color: #2d3748;"></i>
        </div>
        <div class="content">
          <h6 class="text-muted">Hadir</h6>
          <h3 class="text-bold"><?= $total_hadir ?></h3>
        </div>
      </div>
    </div>

    <!-- Alpa -->
    <div class="col-xl-3 col-lg-4 col-sm-6 col-12 mb-4">
      <div class="icon-card card-shadow bg-white rounded-lg p-3 text-center hover-transform">
        <div class="icon primary mb-3">
          <i class="lni lni-cross-circle" style="font-size: 2.5rem; color: #2d3748;"></i>
        </div>
        <div class="content">
          <h6 class="text-muted">Alpa</h6>
          <h3 class="text-bold"><?= $total_siswa - $total_hadir - $ketidakhadiran - 1; ?></h3>
        </div>
      </div>
    </div>

    <!-- Cuti/Izin/Sakit -->
    <div class="col-xl-3 col-lg-4 col-sm-6 col-12 mb-4">
      <div class="icon-card card-shadow bg-white rounded-lg p-3 text-center hover-transform">
        <div class="icon orange mb-3">
          <i class="lni lni-license" style="font-size: 2.5rem; color: #2d3748;"></i>
        </div>
        <div class="content">
          <h6 class="text-muted">Cuti/Izin/Sakit</h6>
          <h3 class="text-bold"><?= $ketidakhadiran ?></h3>
        </div>
      </div>
    </div>
  </div>

  <!-- Grafik -->
  <div class="row justify-content-center">
    <div class="col-12">
      <canvas id="attendanceChart" style="width: 100%; height: 60vh;"></canvas>
    </div>
  </div>
</div>

<style>
  .card-shadow {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease;
  }

  .hover-transform:hover {
    transform: translateY(-10px);
  }

  .rounded-lg {
    border-radius: 0.75rem;
  }

  .icon {
    color: #6c757d;
  }

  .text-bold {
    font-weight: 700;
  }

  @media (max-width: 576px) {
    .icon-card {
      padding: 1.5rem 0.5rem;
    }

    .icon {
      font-size: 1.8rem;
    }

    .text-bold {
      font-size: 1.2rem;
    }
  }
</style>

<!-- Chart.js script -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  var ctx = document.getElementById('attendanceChart').getContext('2d');
  var attendanceChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Total Siswa', 'Hadir', 'Alpa', 'Cuti/Izin/Sakit'],
      datasets: [{
        label: 'Attendance Data',
        data: [
          <?= $total_siswa - 1; ?>,
          <?= $total_hadir; ?>,
          <?= $total_siswa - $total_hadir - $ketidakhadiran - 1; ?>,
          <?= $ketidakhadiran; ?>
        ],
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        borderColor: 'rgba(75, 192, 192, 1)',
        fill: true,
        borderWidth: 1
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      },
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        }
      }
    }
  });
</script>

<?= $this->endSection() ?>