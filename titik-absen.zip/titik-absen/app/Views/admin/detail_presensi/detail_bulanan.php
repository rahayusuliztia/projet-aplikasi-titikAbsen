<?= $this->extend('admin/layout.php') ?>

<?= $this->section('Content') ?>

<?php foreach ($rekap_bulanan as $rekap) : ?>
    <?php
    // Menghitung jumlah jam keterlambatan 
    $jam_masuk_real = strtotime($rekap['jam_masuk']);
    $jam_masuk_kantor = strtotime($rekap['jam_masuk_kantor']);
    $selisih_terlambat = $jam_masuk_real - $jam_masuk_kantor;
    $jam_terlambat = floor($selisih_terlambat / 3600);
    $selisih_terlambat -= $jam_terlambat * 3600;
    $menit_terlambat = floor($selisih_terlambat / 60);

    // Menghitung jam pulang
    $jam_pulang_real = strtotime($rekap['jam_keluar']);
    $jam_pulang_kantor = strtotime($rekap['jam_pulang_kantor']);

    if ($jam_pulang_real == strtotime('00:00:00')) {
        $status_pulang = 'Blm absen plg';
    } elseif ($jam_pulang_real < $jam_pulang_kantor && $jam_pulang_real >= $jam_masuk_kantor) {
        $status_pulang = 'Plg lebih awl';
    } elseif ($jam_pulang_real >= $jam_pulang_kantor && $jam_pulang_real <= strtotime('18:00:00')) {
        $status_pulang = 'Plg tept wktu';
    } else {
        $status_pulang = 'Blm absen plg';
    }

    // Mencari siswa yang sesuai dengan id_siswa dari rekapan harian
    $jenis_kelamin = '';
    $foto_profil = '';
    foreach ($Siswa as $sis) {
        if ($sis['id'] == $rekap['id_siswa']) {
            $jenis_kelamin = $sis['jenis_kelamin'];
            $foto_profil = $sis['foto_siswa'];
            break;
        }
    }
    ?>

    <div class="card shadow-sm mb-4 border-0">
        <div class="card-body">
            <div class="row">
                <!-- Bagian tabel di sebelah kiri -->
                <div class="col-lg-6 col-md-12 mb-3">
                    <table class="table table-borderless">
                        <tr>
                            <td colspan="3">
                                <div class="d-flex align-items-center">
                                    <!-- Gambar di sebelah kiri -->
                                    <div class="me-3">
                                        <img src="<?= base_url('/profile/' . $foto_profil) ?>"
                                            alt="Foto Profil"
                                            class="img-fluid rounded-circle"
                                            style="width: 80px; height: 80px; object-fit: cover;">
                                    </div>
                                    <!-- Nama di sebelah kanan -->
                                    <div>
                                        <span class="fs-4 fw-bold text-dark"><?= $rekap['nama'] ?></span>
                                    </div>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <td class="fw-bold text-muted">Tanggal</td>
                            <td>:</td>
                            <td class="text-dark"><?= date('d F Y', strtotime($rekap['tanggal_masuk'])) ?></td>
                        </tr>
                        <tr>
                            <td class="fw-bold text-muted">Kegiatan</td>
                            <td>:</td>
                            <td class="text-dark"><?= $rekap['kegiatan'] ?></td>
                        </tr>
                        <tr>
                            <td class="fw-bold text-muted">Jam Masuk</td>
                            <td>:</td>
                            <td>
                                <?php if ($rekap['jam_masuk'] <= '09:00:00') : ?>
                                    <span class="badge bg-success"><?= $rekap['jam_masuk'] ?></span>
                                <?php else : ?>
                                    <span class="badge bg-warning"><?= $rekap['jam_masuk'] ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td class="fw-bold text-muted">Jam Keluar</td>
                            <td>:</td>
                            <td>
                                <?php if ($rekap['jam_keluar'] >= '16:00:00' && $rekap['jam_keluar'] <= '18:00:00') : ?>
                                    <span class="badge bg-success"><?= $rekap['jam_keluar'] ?></span>
                                <?php else : ?>
                                    <span class="badge bg-danger"><?= $rekap['jam_keluar'] ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td class="fw-bold text-muted">Status</td>
                            <td>:</td>
                            <td>
                                <span class="badge <?= $rekap['paraf'] == 'pandding' ? 'bg-warning' : ($rekap['paraf'] == 'alfa' ? 'bg-danger' : 'bg-success') ?>">
                                    <?= $rekap['paraf'] ?>
                                </span>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Bagian gambar di sebelah kanan -->
                <div class="col-lg-6 col-md-12 d-flex align-items-center">
                    <div class="row w-100">
                        <!-- Gambar pertama -->
                        <div class="col-md-6 col-sm-12 mb-3">
                            <div class="card h-100 shadow-sm border-0">
                                <img class="card-img-top rounded"
                                    src="<?= empty($rekap['foto_masuk']) ? base_url('/profile/profile-wa-kosong.jpeg') : base_url('/uploads/' . $rekap['foto_masuk']) ?>"
                                    data-bs-toggle="modal" data-bs-target="#imageModal1"
                                    style="cursor: pointer; object-fit: cover;">
                                <div class="card-body text-center">
                                    <p class="card-text fw-bold">Foto Masuk</p>
                                </div>
                                <div class="text-center mt-2 mb-2">
                                    <?php if ($jam_masuk_real < $jam_masuk_kantor) : ?>
                                        <span class="badge bg-success">On time</span>
                                    <?php else : ?>
                                        <span class="badge bg-warning">
                                            Terlambat <?= $jam_terlambat . ' jam ' . $menit_terlambat . ' mnt' ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                        </div>

                        <!-- Gambar kedua -->
                        <div class="col-md-6 col-sm-12 mb-3">
                            <div class="card h-100 shadow-sm border-0">
                                <img class="card-img-top rounded"
                                    src="<?= empty($rekap['foto_keluar']) ? base_url('/profile/profile-wa-kosong.jpeg') : base_url('/uploads/' . $rekap['foto_keluar']) ?>"
                                    data-bs-toggle="modal" data-bs-target="#imageModal2"
                                    style="cursor: pointer; object-fit: cover;">
                                <div class="card-body text-center">
                                    <p class="card-text fw-bold">Foto Keluar</p>
                                </div>
                                <div class="text-center mt-2 mb-2">
                                    <?php if ($status_pulang == 'Blm absen plg') : ?>
                                        <span class="badge bg-danger"><?= $status_pulang ?></span>
                                    <?php elseif ($status_pulang == 'Plg tept wktu') : ?>
                                        <span class="badge bg-success"><?= $status_pulang ?></span>
                                    <?php else : ?>
                                        <span class="badge bg-warning"><?= $status_pulang ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <!-- Modal untuk gambar pertama -->
                <div class="modal fade" id="imageModal1" tabindex="-1" aria-labelledby="imageModalLabel1" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="imageModalLabel1">Foto Masuk</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body text-center">
                                <img src="<?= empty($rekap['foto_masuk']) ? base_url('/profile/profile-wa-kosong.jpeg') : base_url('/uploads/' . $rekap['foto_masuk']) ?>" class="img-fluid rounded">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal untuk gambar kedua -->
                <div class="modal fade" id="imageModal2" tabindex="-1" aria-labelledby="imageModalLabel2" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="imageModalLabel2">Foto Keluar</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body text-center">
                                <img src="<?= empty($rekap['foto_keluar']) ? base_url('/profile/profile-wa-kosong.jpeg') : base_url('/uploads/' . $rekap['foto_keluar']) ?>" class="img-fluid rounded">
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

<?php endforeach ?>

<?= $this->endSection() ?>