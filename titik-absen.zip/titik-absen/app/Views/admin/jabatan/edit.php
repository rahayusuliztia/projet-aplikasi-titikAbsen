<?= $this->extend('admin/layout.php') ?>

<?= $this->section('Content') ?>
    <div class="card col-md-6">
        <div class="card-body ">
        <form action="<?=  base_url('admin/jabatan/update/'
        .$jabatan['id'])?>" method="post">
         <?= csrf_field() ?>
            <div class="input-style-1">
                <label>Nama Jabatan</label>
                <input type="text" name="jabatan" placeholder="Nama Jabatan" value="<?=$jabatan['jabatan'] ?>" class="<?= ($validation->hasError('jabatan')) ? 'is-invalid' : ''  ?> form-control" />
                <div class="invalid-feedback"><?= $validation->getError('jabatan')?></div>
            </div>
            <button type="submit" class="btn btn-primary"> Simpan</button>
         </form>
        </div>
    </div>
<?= $this->endSection() ?>