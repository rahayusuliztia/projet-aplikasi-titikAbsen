<?= $this->extend('admin/layout.php') ?>

<?= $this->section('Content') ?>

<a href="<?= base_url('admin/jabatan/create') ?>" class="btn btn-primary mb-3">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-circle-plus">
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <path d="M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0" />
        <path d="M9 12h6" />
        <path d="M12 9v6" />
    </svg>
    Tambah Data
</a>

<!-- Membuat tabel responsif di layar kecil -->
<div class="table-responsive">
    <table class="table table-striped" id="datatables">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Jabatan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1;
            foreach ($jabatan as $jab) : ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= $jab['jabatan'] ?></td>
                    <td>
                        <!-- Menggunakan kelas `btn-sm` untuk ukuran kecil di perangkat mobile -->
                        <a href="<?= base_url('admin/jabatan/edit/' . $jab['id']) ?>" class="badge bg-primary ">Edit</a>
                        <a href="<?= base_url('admin/jabatan/delete/' . $jab['id']) ?>" class="badge bg-danger tombol-hapus">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?= $this->endSection() ?>