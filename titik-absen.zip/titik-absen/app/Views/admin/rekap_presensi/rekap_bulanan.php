<?= $this->extend('admin/layout.php') ?>

<?= $this->section('Content') ?>

<div class="mb-4">
    <form class="row g-3">
        <div class="col-auto">
            <select name="filter_bulan" class="form-control" required>
                <option value="">--Pilih Bulan--</option>
                <option value="01">Januari</option>
                <option value="02">Februari</option>
                <option value="03">Maret</option>
                <option value="04">April</option>
                <option value="05">Mei</option>
                <option value="06">Juni</option>
                <option value="07">Juli</option>
                <option value="08">Agustus</option>
                <option value="09">September</option>
                <option value="10">Oktober</option>
                <option value="11">November</option>
                <option value="12">Desember</option>
            </select>
        </div>
        <div class="col-auto">
            <select name="filter_tahun" class="form-control" required>
                <option value="2024">2024</option>
                <option value="2025">2025</option>
                <option value="2026">2026</option>
            </select>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-primary mb-3">Tampilkan</button>
        </div>
        <div class="col-auto">
            <button type="submit" name="excel" class="btn btn-success mb-3">Export Excel</button>
        </div>
    </form>
</div>

<span>Menampilkan data:
    <?= $bulan ? date('F Y', strtotime($tahun . '-' . $bulan)) : date('F Y') ?>
</span>

<table class="table table-striped mt-3" id="datatables">
    <thead>
        <tr>
            <th>No</th>
            <th>Profil</th>
            <th>Nama Siswa</th>
            <th>Gender</th>
            <th>Tanggal</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($rekap_bulanan): ?>
            <?php $no = 1; ?>
            <?php foreach ($rekap_bulanan as $rekap): ?>
                <?php
                // Mencari siswa yang sesuai dengan id_siswa dari rekapan bulanan
                $siswa = array_filter($Siswa, fn($sis) => $sis['id'] == $rekap['id_siswa']);
                $siswa = reset($siswa);
                $jenis_kelamin = $siswa['jenis_kelamin'] ?? '';
                $foto_profil = $siswa['foto_siswa'] ?? '';

                // Menghitung jumlah jam keterlambatan
                $jam_masuk_real = strtotime($rekap['jam_masuk']);
                $jam_masuk_kantor = strtotime($rekap['jam_masuk_kantor']);
                $selisih_terlambat = max(0, $jam_masuk_real - $jam_masuk_kantor);
                ?>

                <tr>
                    <td><?= $no++ ?></td>
                    <td>
                        <img src="<?= base_url('profile/' . $foto_profil) ?>" alt="" class="img-thumbnail" style="width: 45px; height: 45px; object-fit: cover; border-radius: 50%;">
                    </td>
                    <td><?= htmlspecialchars($rekap['nama']) ?></td>
                    <td><?= htmlspecialchars($jenis_kelamin) ?></td>
                    <td><?= date('d F Y', strtotime($rekap['tanggal_masuk'])) ?></td>
                    <td class="<?= $rekap['paraf'] === 'alfa' ? 'text-danger' : ($rekap['paraf'] === 'pandding' ? 'text-warning' : 'text-success') ?>">
                        <?= htmlspecialchars($rekap['paraf']) ?>
                    </td>
                    <td>
                        <?php if ($rekap['paraf'] === 'parafed'): ?>
                            <a class="badge bg-primary my-2 mx-2 disabled" href="#" style="opacity: 0.5; pointer-events: none;">Paraf</a>
                        <?php else: ?>
                            <a class="badge bg-primary my-2 mx-2" href="<?= base_url('admin/paraf_absensi/bulanan/' . $rekap['id']) ?>">Paraf</a>
                        <?php endif; ?>
                        <a href="<?= base_url('admin/detail_presensi/detail_bulanan/' . $rekap['id'] . '?filter_bulan=' . $bulan . '&filter_tahun=' . $tahun) ?>" class="badge bg-info">Detail</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="7" class="text-center">Data tidak tersedia</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<?= $this->endSection() ?>