<?= $this->extend('admin/layout.php') ?>

<?= $this->section('Content') ?>

<div class="mb-4">
  <form class="row g-3">
    <div class="col-md-4 col-sm-6 col-12">
      <input type="date" class="form-control" name="filter_tanggal" id="dateinput" required>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
      <button type="submit" class="btn btn-primary mb-3 w-80">Pilih Tanggal</button>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
      <button type="submit" id="excelButton" name="excel" class="btn btn-success mb-3 w-80">Export Excel</button>
    </div>
  </form>
</div>

<span id="ket_tanggal">Menampilkan data:
  <?= $tanggal ? date('d F Y', strtotime($tanggal)) : date('d F Y') ?>
</span>

<div class="table-responsive mt-3">
  <table class="table table-striped" id="datatables">
    <thead>
      <tr>
        <th>No</th>
        <th>Profil</th>
        <th>Nama Siswa</th>
        <th>Gender</th>
        <th>Tanggal</th>
        <th>Status</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($rekap_harian): ?>
        <?php $no = 1; ?>
        <?php foreach ($rekap_harian as $rekap): ?>
          <?php
          $siswa = array_filter($Siswa, fn($sis) => $sis['id'] == $rekap['id_siswa']);
          $siswa = reset($siswa);
          $jenis_kelamin = $siswa['jenis_kelamin'] ?? '';
          $foto_profil = $siswa['foto_siswa'] ?? '';

          // Menghitung keterlambatan
          $jam_masuk_real = strtotime($rekap['jam_masuk']);
          $jam_masuk_kantor = strtotime($rekap['jam_masuk_kantor']);
          $selisih_terlambat = max(0, $jam_masuk_real - $jam_masuk_kantor);
          $jam_terlambat = floor($selisih_terlambat / 3600);
          $menit_terlambat = floor(($selisih_terlambat % 3600) / 60);
          ?>

          <tr>
            <td><?= $no++ ?></td>
            <td>
              <img src="<?= base_url('profile/' . $foto_profil) ?>" alt="" class="img-thumbnail" style="width: 45px; height: 45px; object-fit: cover; border-radius: 50%;">
            </td>
            <td><?= htmlspecialchars($rekap['nama']) ?></td>
            <td><?= htmlspecialchars($jenis_kelamin) ?></td>
            <td><?= date('d F Y', strtotime($rekap['tanggal_masuk'])) ?></td>
            <td class="<?= $rekap['paraf'] === 'alfa' ? 'text-danger' : ($rekap['paraf'] === 'pandding' ? 'text-warning' : 'text-success') ?>">
              <?= htmlspecialchars($rekap['paraf']) ?>
            </td>
            <td>
              <?php if ($rekap['paraf'] === 'parafed'): ?>
                <a class="badge bg-primary my-2 mx-2 disabled" href="#" style="opacity: 0.5; pointer-events: none;">Paraf</a>
              <?php else: ?>
                <a class="badge bg-primary my-2 mx-2" href="<?= base_url('admin/paraf_absensi/harian/' . $rekap['id']) ?>">Paraf</a>
              <?php endif; ?>
              <a href="<?= base_url('admin/detail_presensi/detail_harian/' . $rekap['id'] . '?filter_tanggal=' . $tanggal) ?>" class="badge bg-info">Detail</a>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php else: ?>
        <tr>
          <td colspan="7" class="text-center">Data tidak tersedia</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>




<?= $this->endSection() ?>