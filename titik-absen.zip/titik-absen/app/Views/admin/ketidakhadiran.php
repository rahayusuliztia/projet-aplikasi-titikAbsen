<?= $this->extend('admin/layout.php') ?>

<?= $this->section('Content') ?>

<table class="table table-striped" id="datatables">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Tanggal</th>
            <th>Keterangan</th>
            <th>File</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <?php if ($ketidakhadiran) : ?>
        <tbody>
            <?php $no = 1;
            foreach ($ketidakhadiran as $ketidakhadiran) : ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= $ketidakhadiran['nama_siswa'] ?></td>
                    <td><?= date('d F Y ', strtotime($ketidakhadiran['tanggal'])) ?></td>
                    <td><?= $ketidakhadiran['keterangan'] ?></td>
                    <td>
                        <a class="badge bg-primary " href="<?= base_url('file_ketidakhadiran/' . $ketidakhadiran['file']) ?>">Download</a>
                    </td>
                    <td>
                        <?php if ($ketidakhadiran['status'] == 'pending') : ?>
                            <span class="text-danger"><?= $ketidakhadiran['status'] ?></span>
                        <?php else : ?>
                            <span class="text-success"><?= $ketidakhadiran['status'] ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($ketidakhadiran['status']  == 'Approved') : ?>
                            <a class="badge bg-primary my-2 mx-2 disabled" href="#" onclick="event.preventDefault();" style="opacity: 0.5; pointer-events: none;">Aprove</a>
                        <?php else : ?>
                            <a class="badge mx-2 bg-success" href="<?= base_url('admin/approved_ketidakhadiran/' . $ketidakhadiran['id']) ?>">Aprove</a>
                        <?php endif; ?>
                        <a href="<?= base_url('admin/ketidakhadiran/delete/' . $ketidakhadiran['id']) ?>" class="badge bg-danger tombol-hapus">hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    <?php else : ?>
        <tbody>
            <tr>
                <td class="text-center" colspan="7">Data masih kosong</td>
            </tr>
        </tbody>
    <?php endif; ?>
</table>
<?= $this->endSection() ?>